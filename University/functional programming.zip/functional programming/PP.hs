{- TAREA DE PROGRAMACIÓN FUNCIONAL 2026 -}
{- PRETTY-PRINTING -}
module PP where

import AST

--función Prog: recibe un programa (lista de funciones) y retorna las funciones cada salto de linea -- 
ppProg :: Prog -> String
ppProg [] = ""
ppProg [f] = ppFun f ++ "\n"
ppProg (f:fs) = ppFun f ++ "\n\n" ++ ppProg fs

--función Fun--
ppFun :: Fun -> String
ppFun (Fun nombre arg stmts ret) = "fun " ++ nombre ++ " " ++ arg ++ " {\n" ++ ppStmts 1 stmts ++ "} " ++ ppExp ret ++ ";"

--función Stmts: recibe el nivel de identación y lista de instrucciones e imprime una instrucción por línea --
ppStmts :: Int -> Stmts -> String  
ppStmts _ [] = ""
ppStmts n (s:ss) = ppStmt n s ++ "\n" ++ ppStmts n ss

--funcion Stmt --
ppStmt :: Int -> Stmt -> String
ppStmt n (Assign x e) = indent n ++ x ++ " := " ++ ppExp e ++ ";"

ppStmt n (While cond stmts)= indent n ++ "while " ++ ppExp cond ++ " {\n" ++ ppStmts (n+1) stmts ++ indent n ++ "};"

ppStmt n (If cond then_ else_) =
    indent n ++ "if " ++ ppExp cond ++ " then {\n" ++ 
    ppStmts (n+1) then_ ++
    indent n ++ "} else {\n" ++
    ppStmts (n+1) else_ ++
    indent n ++ "};"

ppStmt n (Case e clauses)=
    indent n ++ "case " ++ ppExp e ++ " of {\n" ++
    concat(map (ppClause (n+1)) clauses) ++
    indent n ++ "};"

--funcion indent: genera 4 espacios--
indent :: Int -> String
indent n = replicate (4*n) ' '

ppClause :: Int -> Clause -> String
ppClause n (Clause pat stmts) = indent n ++ ppPat pat ++ " -> {\n" ++ ppStmts (n+1) stmts ++ indent n ++ "};\n"

--funcion pat: imprime los patrones, los patrones se usan para reconocer la forma de valores dentro de un case--
ppPat :: Pattern -> String
ppPat PNil = "Nil"
ppPat (PCons pat1 pat2) = "(Cons " ++ ppPat pat1 ++ " " ++ ppPat pat2 ++ ")"
ppPat (PLitN n) = show n 
ppPat (PLitB True) = "True"
ppPat (PLitB False) = "False"
ppPat (PVar x) = x


--función Exp: se evaluan las exp y produce un valor--
ppExp :: Exp -> String 
ppExp (LitN n) = show n
ppExp (LitB True) = "True"
ppExp (LitB False) = "False"
ppExp Nil = "Nil"
ppExp (Var x) = x
ppExp (Head e) = "(head " ++ ppExp e ++ ")"
ppExp (Tail e) = "(tail " ++ ppExp e ++ ")"
ppExp (Call f e) = "(" ++ f ++ " " ++ ppExp e ++ ")"
ppExp (Cons e1 e2) = "(Cons " ++ ppExp e1 ++ " " ++ ppExp e2 ++ ")"
ppExp (BinOp op e1 e2) = "(" ++ ppExp e1 ++ " " ++ ppBOp op ++ " " ++ ppExp e2 ++ ")"
ppExp (UnOp op e) = "(" ++ ppUOp op ++ ppExp e ++ ")"

--funciones BOp y ppUOp--
ppBOp :: BOp -> String 
ppBOp Add = "+"
ppBOp Sub = "-"
ppBOp Times = "*"
ppBOp Div = "/"
ppBOp Mod = "%"
ppBOp And = "&&"
ppBOp Or = "||"
ppBOp Equ = "=="
ppBOp Lt = "<"

ppUOp :: UOp -> String 
ppUOp Minus = "-" 
ppUOp Not = "!"
