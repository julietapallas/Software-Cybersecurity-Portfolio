{- TAREA DE PROGRAMACIÓN FUNCIONAL 2026 -}
{- CHEQUEO DE NOMBRES Y TIPOS -}
module TypeChecker where

import AST

-- Tipos
data Type = TInt | TBool | TList
  deriving Eq

-- Resultado de un Chequeo
data CheckRes = Ok
              | HasNameErrors [NameError]
              | HasTypeErrors [TypeError]

-- Errores de Nombres
data NameError
  = UndefVar Id
  | UndefFun Id
  | DupFun Id
  | DupVar Id

-- Errores de Tipos
data TypeError
  = CallArgType Id Type
  | BinOpWrongType BOp Type Type
  | UnOpWrongType UOp Type
  | CondNotBool Type
  | AssignTypeMismatch Id Type Type
  | PatMismatch Type Type
  | ConsExpType Type Type
  | HeadTailArg Type
  | WrongReturnType Id Type


-- Instancias de Show de tipos y resultados
instance Show Type where
  show TInt = "int"
  show TBool = "bool"
  show TList = "list"

instance Show NameError where
  showsPrec _ err = case err of
    UndefVar x ->
      showString "undefined variable: " . showString x

    UndefFun f ->
      showString "undefined function: " . showString f

    DupFun f ->
      showString "duplicated function: " . showString f

    DupVar v ->
      showString "duplicated variable: " . showString v

instance Show TypeError where
  showsPrec _ err = case err of
    CallArgType f t ->
      showString "invalid argument type in "
      . showString f
      . showString ": "
      . shows t

    BinOpWrongType bop t1 t2 ->
      showString "invalid argument type/s in operator "
      . shows bop
      . showString ": "
      . shows t1
      . showString ", "
      . shows t2

    UnOpWrongType uop t ->
      showString "invalid argument type in unary operator "
      . shows uop
      . showString ": "
      . shows t

    CondNotBool t ->
      showString "invalid condition type: "
      . shows t

    AssignTypeMismatch x t1 t2 ->
      showString "invalid assignment in "
      . showString x
      . showString ": expected "
      . shows t1
      . showString ", actual "
      . shows t2

    PatMismatch t1 t2 ->
      showString "invalid pattern: expected "
      . shows t1
      . showString ", actual "
      . shows t2

    ConsExpType t1 t2 ->
      showString "invalid argument type/s in Cons: "
      . shows t1
      . showString ", "
      . shows t2

    HeadTailArg t ->
      showString "invalid list argument type: "
      . shows t

    WrongReturnType f t ->
      showString "invalid return type in "
      . showString f
      . showString ": "
      . shows t

instance Show CheckRes where
  showsPrec _ Ok = showString "ok"
  showsPrec _ (HasNameErrors errs) = showLines errs
  showsPrec _ (HasTypeErrors errs) = showLines errs

showLines :: Show a => [a] -> ShowS
showLines =
  foldr1 (\x acc -> x . showChar '\n' . acc) . map shows


-- Chequeo de un programa.
-- El comportamiento de la función se especifica en la letra de la Tarea.
checkProg :: Prog -> CheckRes
checkProg p = 
    case checkNombresProg p of
      [] -> 
        case checkTiposProg p of 
          [] -> Ok 
          errs -> HasTypeErrors errs 
      errs -> HasNameErrors errs

checkNombresProg :: Prog -> [NameError]
checkNombresProg = recorrer []  --LISTA DE FUNCIONES YA VISTAS--
  where
    recorrer _ [] = []   --si no quedan funciones para recorrer -> no hay más errores que buscar
    recorrer funciones (f@(Fun nombre arg stmts ret):fs)=   -- parametros: funciones es una lista con los nombres  de las funs vistas, lista de funciones
      duplicado ++ errsFun ++ recorrer (funciones ++ [nombre]) fs  --errores: funcion duplicada, dentro de la funcion, funciones q faltan recorrer
      where
        duplicado
          | elemento nombre funciones = [DupFun nombre]  -- si elemento nombre funciones == true -> devuelve el error
          | otherwise = []
        errsFun = checkFunNombres funciones f

--función que devuelve true si un elemento está en la lista, false caso contrario
elemento :: Id -> [Id] -> Bool
elemento _ [] = False
elemento x (y:ys) = x == y || elem x ys

checkFunNombres :: [Id] -> Fun -> [NameError]
checkFunNombres funciones (Fun _ arg stmts ret) =
    checkStmts funciones [arg] stmts ++ checkExpNombres funciones (variablesStmts [arg] stmts) ret

--variables_stmts calcula cuales variables existen al terminar el bloque
variablesStmts :: [Id] -> Stmts -> [Id]
variablesStmts vars [] = vars 
variablesStmts vars (Assign x _ : ss) = variablesStmts (if elemento x vars then vars else vars ++ [x]) ss
variablesStmts vars (_:ss) = variablesStmts vars ss


--checkstmts chequea todas las instrucciones sabiendo que ini la única var def es [arg] (vars)
checkStmts :: [Id] -> [Id] -> Stmts -> [NameError]
checkStmts _ _ [] = []
checkStmts funciones vars (s:ss) = checkStmt funciones vars s ++ checkStmts funciones (agregarVars vars s) ss

agregarVars :: [Id] -> Stmt -> [Id]
agregarVars vars (Assign x _) = if elemento x vars then vars else vars ++ [x]
agregarVars vars _ = vars

--checkStmt chequea solo una instruccion 
checkStmt :: [Id] -> [Id] -> Stmt -> [NameError] 
checkStmt funciones vars (Assign _ e) = checkExpNombres funciones vars e --funciones y vars son conocidas
checkStmt funciones vars (While e body) = checkExpNombres funciones  vars e ++ checkStmts funciones vars body 
checkStmt funciones vars (If e t f) = 
  checkExpNombres funciones vars e ++ checkStmts funciones vars t ++ checkStmts funciones vars f
checkStmt funciones vars (Case e clauses) = 
  checkExpNombres funciones vars e 
  ++ concat(map(checkClause funciones vars) clauses)

--checkClause chequea una cláusula de un case
checkClause :: [Id] -> [Id] -> Clause -> [NameError] 
checkClause funciones vars (Clause pat stmts) = perrs ++ checkStmts funciones (vars ++ pvars) stmts
  where (perrs,pvars) = checkPattern vars pat  

--checkPattern devuelve tupla de errores del patrón y variables declaradas por el patrón
checkPattern :: [Id] -> Pattern -> ([NameError] , [Id])
checkPattern vars p = 
  let xs = patVars p 
      dups = duplicados xs 
      errs1 = map DupVar dups --trnasforma nombres repetidos en errores dentro del mismo patron
      errs2 = [DupVar x| x <- xs, elemento x vars] -- se buscan vars del patron que ya exitian antes
  in (errs1 ++ errs2 , xs)

-- patVars obtiene todas las vars que aparecen en un patrón
patVars :: Pattern -> [Id] 
patVars PNil = []
patVars (PLitN _) = []
patVars (PLitB _) = []
patVars (PVar x) = [x]
patVars (PCons p1 p2) = patVars p1 ++ patVars p2

--duplicados busca elementos repetidos en una lista
duplicados :: [Id] -> [Id]
duplicados = recorrer []
  where 
    recorrer _ [] = []
    recorrer elemvistos (x:xs)
      | elemento x elemvistos = x : recorrer elemvistos xs 
      | otherwise = recorrer (x : elemvistos) xs


-- checkExpNombres chequea la exp de retorno
checkExpNombres :: [Id] -> [Id] -> Exp -> [NameError] 
checkExpNombres _ _ (LitN _) = [] 
checkExpNombres _ _ (LitB _) = [] 
checkExpNombres _ _ Nil = [] 

checkExpNombres _ vars (Var x) 
  | elemento x vars = []
  | otherwise = [UndefVar x]  --Variebles no def

checkExpNombres  funciones vars (Call f e) = 
  let funerr = 
        if elemento f funciones 
        then [] 
        else [UndefFun f] -- funciones no def
  in funerr ++ checkExpNombres funciones vars e --luego chequea sus args

checkExpNombres funciones vars (UnOp _ e) = checkExpNombres funciones vars e 
checkExpNombres funciones vars (Head e) = checkExpNombres funciones vars e 
checkExpNombres funciones vars (Tail e) = checkExpNombres funciones vars e 
checkExpNombres funciones vars (Cons e1 e2 ) = checkExpNombres funciones vars e1 ++ checkExpNombres funciones vars e2
checkExpNombres funciones vars (BinOp _ e1 e2) = checkExpNombres funciones vars e1  ++ checkExpNombres funciones vars e2


-------------
type Ttipos =[(Id, Type)] --lista de pares (Id,Type)

type FunTipos = [Id]  --lista de funciones válidas en el prog para chequear las llamadas

checkTiposProg :: Prog -> [TypeError]
checkTiposProg = concatMap checkFunTipos 

checkFunTipos :: Fun -> [TypeError] 
checkFunTipos (Fun nombre arg stmts ret) = 
  let (_ , errs1) = checkStmtsTipos [(arg , TList)] stmts 
      tiposFinal = tiposDespStmts [(arg, TList )] stmts 
      (tret, errs2) = detTipoExp tiposFinal ret 
      errRet = if tret == TList then [] else [WrongReturnType nombre tret]
  in errs1 ++ errs2 ++ errRet

--tipos desp de ejecutar un bloque 
tiposDespStmts :: Ttipos -> Stmts -> Ttipos 
tiposDespStmts tipos [] = tipos 

--assign
tiposDespStmts tipos (Assign x e : ss) =
  let (t, _) = detTipoExp tipos e 
      tipos1 = 
        case lookup x tipos of 
          Nothing -> (x,t) : tipos 
          Just _ -> tipos 
  in tiposDespStmts tipos1 ss 

tiposDespStmts tipos (_: ss) = tiposDespStmts tipos ss

--chequeo de instrucciones
checkStmtsTipos :: Ttipos -> Stmts -> (Ttipos , [TypeError])
checkStmtsTipos tipos [] = (tipos , [])
checkStmtsTipos tipos (s:ss) = 
  let (tipos1, errs1) = checkStmtTipos tipos s 
      (tipos2, errs2) = checkStmtsTipos tipos1 ss 
  in (tipos2, errs1 ++ errs2)

--chequeo una istruccion
checkStmtTipos :: Ttipos -> Stmt -> (Ttipos, [TypeError])
--assign
checkStmtTipos tipos (Assign x e ) = 
  let (t, errs ) = detTipoExp tipos e 
  in case lookup x tipos of 
      Nothing -> ((x, t):tipos , errs)
      Just tx -> if tx == t then (tipos, errs) else (tipos, errs ++ [AssignTypeMismatch x tx t])

--while 
checkStmtTipos  tipos (While e body) =
  let (t , errs1) = detTipoExp tipos e 
      condErr = if t == TBool then [] else [CondNotBool t] 
      (_, errs2) = checkStmtsTipos tipos body 
  in (tipos, errs1 ++ condErr ++ errs2)

--if 
checkStmtTipos tipos (If e s1 s2 ) =
  let (t, errs1) = detTipoExp tipos e 
      condErr = if t == TBool then [] else [CondNotBool t]
      (_, errs2) = checkStmtsTipos tipos s1
      (_, errs3) = checkStmtsTipos tipos s2
  in ( tipos, errs1 ++ condErr ++ errs2 ++ errs3)

--case
checkStmtTipos tipos (Case e clauses ) =
  let (te, errs1) = detTipoExp tipos e 
      errs2 = concatMap (checkClauseTipos tipos te) clauses 
  in (tipos, errs1 ++ errs2)

matchPatternType :: Type -> Pattern -> (Ttipos, [TypeError])
matchPatternType t (PVar x) = ([(x,t)],[])
matchPatternType t PNil = if t == TList then ([], []) else ([], [PatMismatch t TList])
matchPatternType t (PLitN _) = if t == TInt then ([], []) else ([], [PatMismatch t TInt]) 
matchPatternType t (PLitB _) = if t == TBool then ([], []) else ([], [PatMismatch t TBool]) 

matchPatternType t (PCons p1 p2) 
  | t/= TList = ([], [PatMismatch t TList]) 
  | otherwise =
    let (tipos1, e1 )= matchPatternType TInt p1 
        (tipos2, e2 )= matchPatternType TList p2
        t1 = case e1 of 
              [PatMismatch _ actual] -> actual
              _ -> TInt 
        t2 = case e2 of 
              [PatMismatch _ actual] -> actual
              _ -> TList 
        erroresFinales = if null e1 then [] else [ConsExpType t1 t2]
    in (tipos1 ++ tipos2, erroresFinales)

--clausulas
checkClauseTipos :: Ttipos -> Type -> Clause -> [TypeError]
checkClauseTipos tipos te (Clause pat stmts) = 
  let (penv, errs1) = matchPatternType te pat 
      (_, errs2) = checkStmtsTipos (penv ++ tipos) stmts 
  in errs1 ++ errs2 

--determinar que tipo tiene la expresion
detTipoExp :: Ttipos -> Exp -> (Type, [TypeError])
detTipoExp _ (LitN _) = (TInt , [])
detTipoExp _ (LitB _) = (TBool , [])
detTipoExp _ Nil = (TList , [])
detTipoExp tipos (Var x) = (buscar x tipos, [])
  where
      buscar x tipos = 
        case lookup x tipos of 
          Just t -> t

detTipoExp tipos (Head e) = 
  let (t, errs) = detTipoExp tipos e 
      err = if t == TList then [] else [HeadTailArg t] 
  in (TInt , errs ++ err)

detTipoExp tipos (Tail e) = 
  let (t, errs) = detTipoExp tipos e 
      err = if t == TList then [] else [HeadTailArg t] 
  in (TList , errs ++ err)

detTipoExp tipos (Call f e) =
  let (t,errs) = detTipoExp tipos e
      err = if t ==TList then [] else [CallArgType f t]
  in (TList , errs ++ err)

detTipoExp tipos (Cons e1 e2) =
  let (t1, err1) = detTipoExp tipos e1 
      (t2, err2) = detTipoExp tipos e2 
      err = if t1 == TInt &&  t2 ==TList then [] else [ConsExpType t1 t2]
  in (TList, err1 ++ err2 ++ err)

detTipoExp tipos (UnOp Minus e) = 
  let (t, errs) = detTipoExp tipos e 
      err = if t == TInt then [] else [UnOpWrongType Minus t] 
  in (TInt, errs ++ err)

detTipoExp tipos (UnOp Not e) = 
  let (t, errs) = detTipoExp tipos e 
      err = if t ==TBool then [] else [UnOpWrongType Not t] 
  in (TBool , errs ++ err)

detTipoExp tipos (BinOp op e1 e2) =
  let (t1, err1) = detTipoExp tipos e1 
      (t2, err2) = detTipoExp tipos e2 
      err = checkBin op t1 t2 
  in (resultType op, err1 ++ err2 ++ err)
  where 
    checkBin Add t1 t2 = if t1 == TInt && t2 == TInt then [] else [BinOpWrongType Add t1 t2]
    checkBin Sub t1 t2 = if t1 == TInt && t2 == TInt then [] else [BinOpWrongType Sub t1 t2]
    checkBin Times t1 t2 = if t1 == TInt && t2 == TInt then [] else [BinOpWrongType Times t1 t2]
    checkBin Div t1 t2 = if t1 == TInt && t2 == TInt then [] else [BinOpWrongType Div t1 t2]
    checkBin Mod t1 t2 = if t1 == TInt && t2 == TInt then [] else [BinOpWrongType Mod t1 t2]
    checkBin And t1 t2 = if t1 == TBool && t2 == TBool then [] else [BinOpWrongType And t1 t2]
    checkBin Or t1 t2 = if t1 == TBool && t2 == TBool then [] else [BinOpWrongType Or t1 t2]
    checkBin Lt t1 t2 = if t1 == TInt && t2 == TInt then [] else [BinOpWrongType Lt t1 t2]
    checkBin Equ t1 t2 = if t1 == t2 then [] else [BinOpWrongType Equ t1 t2]

    resultType Add = TInt
    resultType Sub = TInt
    resultType Times = TInt
    resultType Div = TInt
    resultType Mod = TInt
    resultType And = TBool
    resultType Or= TBool
    resultType Lt = TBool
    resultType Equ = TBool


-- Chequeo de una expresión.
-- El comportamiento de la función se especifica en la letra de la Tarea.
checkExp :: Prog -> Exp -> CheckRes
checkExp prog e = 
  let funciones = map (\(Fun f _ _ _) -> f) prog 
      nerrs = checkExpNombres funciones [] e
  in case nerrs of 
    [] -> 
      let (_ ,terrs)  = detTipoExp [] e 
      in if null terrs then Ok else HasTypeErrors terrs 
    _ -> HasNameErrors nerrs


