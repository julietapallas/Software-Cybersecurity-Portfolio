{- TAREA DE PROGRAMACIÓN FUNCIONAL 2026 -}
{- EVALUACIÓN DE EXPRESIONES -}
module Eval where

import AST
import State


-- Resultado de una evaluación
type EvalRes = Either RuntimeError Val

-- Errores en tiempo de ejecución
data RuntimeError
  = HeadOfEmptyList
  | TailOfEmptyList
  | DivisionByZero
  deriving Eq

instance Show RuntimeError where
  show HeadOfEmptyList = "head of empty list"
  show TailOfEmptyList = "tail of empty list"
  show DivisionByZero  = "division by zero"

  
-- Evalúa una expresión.
-- El comportamiento de la función se especifica en la letra de la Tarea.
evalExp :: Prog -> State -> Exp -> EvalRes
--expresiones
evalExp _ _ (LitN n) = Right (ValInt  n)
evalExp _ _ (LitB b) = Right (ValBool b)
evalExp _ _ Nil = Right (ValList  [])

--variables 
evalExp _ estado (Var x) = 
  case get x estado of 
    Just v -> Right v 
    Nothing -> Right (ValInt 0)

--head
evalExp p estado (Head e) =
  case evalExp p estado e of 
    Left err -> Left err 
    Right (ValList []) -> Left HeadOfEmptyList 
    Right (ValList (x:_)) -> Right (ValInt x)
    _ -> Right (ValInt 0)

--tail 
evalExp p estado (Tail e) =
  case evalExp p estado e of 
    Left err -> Left err 
    Right (ValList []) -> Left TailOfEmptyList 
    Right (ValList (_:xs)) -> Right (ValList xs) 
    _ -> Right (ValList [])

--cons
evalExp p estado (Cons e1 e2) =
  case evalExp p estado e1 of 
    Left err -> Left err 
    Right (ValInt x) -> 
      case evalExp p estado e2 of 
        Left err -> Left err 
        Right (ValList xs) -> Right (ValList (x:xs))

evalExp p estado (BinOp op e1 e2 ) = 
  case evalExp p estado e1 of
    Left err -> Left err
    Right v1 -> 
      case evalExp p estado e2 of 
        Left err -> Left err 
        Right v2 -> evalBin op v1 v2 

evalExp p estado (UnOp Not e) = 
  case evalExp p estado e of 
    Right (ValBool b) -> Right (ValBool (not b)) 
    Left err -> Left err 

evalExp p estado (UnOp Minus e) = 
  case evalExp p estado e of 
    Right (ValInt x) -> Right (ValInt (-x)) 
    Left err -> Left err 

evalExp prog estado (Call f e ) = 
  case evalExp prog estado e of 
    Left err -> Left err 
    Right argVal -> 
      let Fun _ parametro stmts ret = buscarFun f prog 
          estado1 = new parametro argVal (newFrame estado ) --creo nuevo frame y agrego el parametro
      in case ejecutarStmts prog estado1 stmts of 
        Left err -> Left err 
        Right estado2 ->
          case evalExp prog estado2 ret of 
            Left err -> Left err
            Right retVal -> Right retVal


evalBin :: BOp -> Val -> Val -> Either RuntimeError Val
evalBin Add (ValInt x) (ValInt y ) = Right (ValInt (x+y))
evalBin Lt (ValInt x) (ValInt y ) = Right (ValBool (x<y))
evalBin Equ v1 v2 = Right (ValBool (v1==v2))
evalBin Div (ValInt _) (ValInt 0) = Left DivisionByZero 
evalBin Div (ValInt x) (ValInt y) = Right (ValInt (x `div` y))
evalBin Sub (ValInt x) (ValInt y) = Right (ValInt (x-y))
evalBin Times (ValInt x) (ValInt y) = Right (ValInt (x*y)) 
evalBin Mod (ValInt x) (ValInt y) 
  | y == 0 = Left DivisionByZero 
  |otherwise = Right (ValInt (mod x y )) 

evalBin And (ValBool x) (ValBool y) = Right (ValBool (x && y))
evalBin Or (ValBool x) (ValBool y) = Right (ValBool (x || y))



buscarFun::Id -> Prog ->Fun 
buscarFun f (fun@(Fun nombre _ _ _): fs)
  | f == nombre = fun 
  | otherwise = buscarFun f fs 

ejecutarStmts :: Prog -> State -> Stmts -> Either RuntimeError State 
ejecutarStmts _ estado [] = Right estado 
ejecutarStmts prog estado (s:ss) = 
  case ejecutarStmt prog estado s of 
    Left err -> Left err 
    Right estado1 -> ejecutarStmts prog estado1 ss 

ejecutarStmt :: Prog -> State -> Stmt -> Either RuntimeError State 
--assign 
ejecutarStmt prog estado (Assign x e) = 
  case evalExp prog estado e of 
    Left err -> Left err 
    Right val -> Right (set x val estado)

-- if 
ejecutarStmt prog estado (If cond tBlock fBlock) = 
  case evalExp prog estado cond of 
    Left err -> Left err 
    Right (ValBool True ) -> ejecutarStmts prog estado tBlock 
    Right (ValBool False) -> ejecutarStmts prog estado fBlock 

--while
ejecutarStmt prog estado (While cond body) =
  case evalExp prog estado cond of 
    Left err -> Left err 
    Right (ValBool True) ->
      case ejecutarStmts prog estado body of 
          Left err -> Left err 
          Right estado1 -> ejecutarStmt prog estado1 (While cond body)
    Right (ValBool False) -> Right estado 

--case 
ejecutarStmt prog estado (Case e clauses) = 
  case evalExp prog estado e of
    Left err -> Left err 
    Right val -> ejecutarClauses prog estado val clauses 

-- recorre las clauslas hasta q haga match
ejecutarClauses :: Prog -> State -> Val -> [Clause] -> Either RuntimeError State 
ejecutarClauses _ estado _ [] = Right estado 
ejecutarClauses prog estado val (Clause pat stmts : cs) =
    case matchPattern pat val of
      Just nuevoFrame -> 
        let estadoConPatron = meterFrame nuevoFrame estado 
        in case ejecutarStmts prog estadoConPatron stmts of 
          Left err -> Left err 
          Right estado2 -> Right (dropFrame estado2)
      Nothing ->
        ejecutarClauses prog estado val cs 

meterFrame :: Frame -> State -> State 
meterFrame fr estado = fr : estado 

matchPattern :: Pattern -> Val -> Maybe Frame 
matchPattern (PVar x) val =Just [(x, val)]
matchPattern (PLitN n1) (ValInt n2) = if n1 == n2 then Just [] else Nothing
matchPattern (PLitB b1) (ValBool b2) = if b1 == b2 then Just [] else Nothing
matchPattern PNil (ValList []) = Just [] 
matchPattern (PCons p1 p2) (ValList (x:xs)) = 
  case matchPattern p1 (ValInt x ) of 
    Nothing -> Nothing 
    Just f1 -> 
      case matchPattern p2 (ValList xs ) of 
        Nothing -> Nothing 
        Just f2 -> Just (f1 ++ f2)
matchPattern _ _ = Nothing
