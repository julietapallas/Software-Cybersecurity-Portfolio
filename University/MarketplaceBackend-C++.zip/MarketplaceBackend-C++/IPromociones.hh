#ifndef __IPROMOCIONES__HH__
#define __IPROMOCIONES__HH__
#include "DT.hh"

class IPromociones{
public:
    virtual ~IPromociones() {};
    virtual void ingresarPromo(DTPromocion Promocion) = 0;
    virtual set<string> obtenerVendedores() = 0;
    virtual set<DTProductoCN> obtenerProductosVend(string nickname) = 0;
    virtual bool selecProd(ParCodCant Prod) = 0;
    virtual bool altaPromocion() = 0;
    virtual DTProm DatosPromocion(DTPromocion PromElegida) = 0;
    virtual set<DTPromocion> IniciarConsulta() = 0;
};

#endif