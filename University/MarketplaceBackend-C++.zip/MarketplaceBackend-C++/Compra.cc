#ifndef __COMPRA__CC
#define __COMPRA__CC
#include "Compra.hh"

Compra::Compra(DTFecha F, float Mf):Fecha(F){
    Fecha = F;
    Montofinal = Mf;
}
Compra::~Compra(){}
void Compra::setFecha(DTFecha F){
    Fecha = F;
}
void Compra::setMontofinal(float Mf){
    Montofinal = Mf;
}
void Compra::setCompraProd(CompraProducto*CP){
    CompraProd.push_back(CP);
}
void Compra::setUsuario(Usuario *u){
    usuario = u;
}

void Compra::setId(int i){
    id = i;
}

DTFecha Compra::getFecha(){
    return Fecha;
}
float Compra::getMontofinal()
{
    return Montofinal;
}

vector<CompraProducto *> Compra::getCompraProd(){
    return CompraProd;
}
Usuario *Compra::getUsuario(){
    return usuario;
}

int Compra::getId(){
    return id;
}

void Compra::setCompra(float Mf, DTFecha F)
{
}

bool Compra::CorrespondeCompra(int cod){
    bool ret = false;
    for (int i = 0; i < CompraProd.size() && !ret; i++){
        if (!CompraProd[i]->getEnviado()&&(CompraProd[i]->getProducto()->getCodigo() == cod)){
            ret = true;
        }
    }
    return ret;
}

ParClienteCompra Compra::getParClienteCompra(){
    ParClienteCompra PCliComp(usuario->getNickname(),id,Fecha);
    return PCliComp;
}

void Compra :: marcarProdEnviado(int cod){
    for (int i = 0; i< CompraProd.size(); i++){
        if (CompraProd[i]->getProducto()->getCodigo() == cod){
            CompraProd[i]->setEnviado(true);
        }
    }
}

ParCompraProductos Compra::obtenerParCompraProductos(){
    DTCompra compra(Montofinal,Fecha);
    set<DTProducto> productos = {};
    for(int i=0;i != CompraProd.size();i++){
        CompraProducto* cp = CompraProd[i];
        Producto* prod = cp->getProducto();
        productos.insert(prod->getDTProducto());
    }
    ParCompraProductos par(compra,productos);
    return par;
}
#endif
