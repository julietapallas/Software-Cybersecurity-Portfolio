#include"Vendedor.hh"
#include "ControladorProductos.hh"
#include "ControladorPromociones.hh"

Vendedor :: Vendedor (string nick, string cont, string RUT, DTFecha FN): Usuario (nick, cont, FN) {
    codigoRUT = RUT;
}

Vendedor :: ~Vendedor() {

}

string Vendedor :: getCodigoRUT() {
    return codigoRUT;
}

void Vendedor :: setCodigoRUT(string RUT) {
    codigoRUT = RUT;
}

DTVendedor Vendedor :: getDTVendedor() {
    DTVendedor dtv = DTVendedor(getNickname(),getContrasenia(),getFecha(),codigoRUT);
    return dtv;
}

DTExpU* Vendedor::obtenerExpediente(){
    DTVendedor vendedor(getNickname(),getContrasenia(),getFecha(),codigoRUT);
    
    ControladorProductos* CP = ControladorProductos::getInstancia();
    set<DTProducto> productos = CP->productosDelVendedor(getNickname());
    
    ControladorPromociones* CPP = ControladorPromociones::getInstancia();
    set<DTPromocion> promociones = CPP->promocionesDelVendedor(getNickname());
    
    DTExpV* expediente = new DTExpV(vendedor,productos,promociones);
    return expediente;
}
