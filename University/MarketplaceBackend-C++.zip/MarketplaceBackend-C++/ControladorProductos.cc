#include "ControladorProductos.hh"
#include "ControladorUsuarios.hh"
#include "PromocionProducto.hh"

ControladorProductos::ControladorProductos(){
    Contador=0;
}



ControladorProductos* ControladorProductos::InstControladorProd=nullptr;
ControladorProductos* ControladorProductos:: getInstancia(){
    if (InstControladorProd==nullptr){
        InstControladorProd= new ControladorProductos();
}
    return InstControladorProd;

}


int ControladorProductos:: ingresarProducto(int cod, int cant) {
    map<int, Producto*>::iterator prod = ColeccionProds.find(cod);
    if(prod != ColeccionProds.end()){
        return prod->second->getStock();
    }else return 0;
}

float ControladorProductos::ObtenerPrecio(set<ParCodCant> cc) {
    FechaAct* fechaActual = FechaAct::getInstancia();
    DTFecha DTActual = fechaActual->getDTFecha();    
    
    set<Promocion*> promocionesPosibles;
    set<int> codProds;
    for (set<ParCodCant>::iterator par = cc.begin(); par != cc.end(); ++par) {
        codProds.insert(par->getCodigo());
        Producto* prod = ColeccionProds[par->getCodigo()];
        PromocionProducto* pprod = prod->getPromProd();
        
        if (pprod != nullptr) {
            Promocion* promo = pprod->getPromocion();
            if (DTActual <= pprod->getFecha()) {
                promocionesPosibles.insert(promo);
            }
        }
    }

    set<Promocion*> promosvalidas;
    for (set<Promocion*>::iterator it = promocionesPosibles.begin(); it != promocionesPosibles.end(); ++it) {
        Promocion* promo = *it;
        bool promocion_valida = true;
        const set<PromocionProducto*>& CPromProds = promo->getColeccionPromProds(); 
        for (set<PromocionProducto*>::iterator cpp = CPromProds.begin(); cpp != CPromProds.end(); ++cpp) {
            int codProd = (*cpp)->getProducto()->getCodigo();
            bool cumpleCantidad = true;           
            for (set<ParCodCant>::iterator par = cc.begin(); par != cc.end(); ++par) {
                if (par->getCodigo() == codProd && par->getCantidad() >= (*cpp)->getCantMin()) {
                    cumpleCantidad = false;
                    break;
                }
            }
            if (cumpleCantidad) {
                promocion_valida = false;
                break;
            }
        }
        if (promocion_valida) {
            promosvalidas.insert(promo);
        }
    }

    float total = 0.0f;
    for (set<ParCodCant>::iterator it = cc.begin(); it != cc.end(); ++it) {
        Producto* prod = ColeccionProds[it->getCodigo()];
        int cantidad = it->getCantidad();
        PromocionProducto* pp = prod->getPromProd();
        float costoProd;
        if (pp != nullptr && (promosvalidas.find(pp->getPromocion()) != promosvalidas.end())) {
            float desc = pp->ObtenerDescuento();
            costoProd = prod->getPrecio() * (1.0f - desc / 100.0f) * cantidad;
        } else {
            costoProd = prod->getPrecio() * cantidad;
        }
        total = total + costoProd;
    }

    return total;
}


  set<DTProducto> ControladorProductos::AsociarProductos(set<ParCodCant> ListaProds,Promocion* p){
    set<DTProducto> vec={};
    set<ParCodCant>::iterator it;
    for (it = ListaProds.begin(); it != ListaProds.end();++it){

        Producto* Prod = ColeccionProds.find((*it).getCodigo())->second;

        PromocionProducto* pp = new PromocionProducto((*it).getCantidad(),p,Prod);

        Prod->Asociar(pp);
        p->Asociar(pp);

        DTProducto dtProd(Prod->getNombre(),Prod->getDescripcion(),to_string(Prod->getCodigo()),Prod->getPrecio(),Prod->getStock(),Prod->getCategoria());
        vec.insert(dtProd);
    }

    
    return vec;
}



set<DTProductoCN> ControladorProductos:: ObtenerProductosVend(string nickname){
    set<DTProductoCN> ret = {};
    for (map<int,Producto*>:: iterator it = ColeccionProds.begin(); it!=ColeccionProds.end(); ++it){
        Producto* actual = it->second;
        if (actual->prodValido(nickname)){
            string nombre = actual->getNombre();
            int codigo = actual->getCodigo();
            DTProductoCN Prod(nombre,to_string(codigo));
            ret.insert(Prod);
        }
    }
return ret;
}

set<DTProducto> ControladorProductos::elegirCliente(string nick){
    set<DTProducto> res;
     map<int,Producto*>::iterator it;
    for (it = ColeccionProds.begin(); it != ColeccionProds.end();++it) {
            Producto* p = it->second;
            DTProducto prod = DTProducto(p->getNombre(), p->getDescripcion(), to_string(p->getCodigo()), p->getPrecio(), p->getStock(), p->getCategoria());
            res.insert(prod);
    }
    return res;
}

int ControladorProductos:: ingresarProducto(DTProductoSinC dataProducto, string nickVendedor) {
    Contador++;
    ControladorUsuarios* Cusuarios = ControladorUsuarios::getInstancia();
    Producto * nuevoprod= new Producto(dataProducto.getNombre(),dataProducto.getPrecio(),dataProducto.getStock(),dataProducto.getDescripcion(),dataProducto.getCategoria(),Contador,Cusuarios->getUsuario(nickVendedor),nullptr,vector<CompraProducto*>());
    ColeccionProds[Contador] = (nuevoprod);
    
return Contador;
}
set<string> ControladorProductos :: obtenerVendedores(){
ControladorUsuarios * Cusuarios = ControladorUsuarios::getInstancia();
return Cusuarios->obtenerVendedores();
};

void ControladorProductos::setContador(int cont){
    Contador = cont;
}

int ControladorProductos::getContador(){
    return Contador;
}

bool ControladorProductos::esVendedor(string nick, int cod) {
    bool ret = false;
    map<int,Producto*>::iterator it = ColeccionProds.find(cod);
    if (it != ColeccionProds.end() && (it)->second->getCodigo() == cod) {
        ret = (nick == (it)->second->getVendedor()->getNickname());
    }

    return ret;
}

bool ControladorProductos::existeProducto(int cod){
    if(ColeccionProds.count(cod) == 0)
        return false;
    else return true;
}

ParVendedorProducto ControladorProductos::mostrarProducto(int prod){

    Producto* producto = ColeccionProds[prod];
    DTProductoInfo pInfo = DTProductoInfo(producto->getPrecio(), producto->getStock(), producto->getDescripcion(), producto->getCategoria());
    return ParVendedorProducto(producto->getVendedor()->getNickname(), pInfo);
}

 set<DTProductoCN> ControladorProductos::ObtenerListaProductos(){
    set<DTProductoCN> res;
    for(map<int,Producto*>::iterator it = ColeccionProds.begin(); it != ColeccionProds.end();it++){
        DTProductoCN prod = DTProductoCN(it->second->getNombre(), to_string(it->second->getCodigo()));
        res.insert(prod);
    }
    return res;
}

Producto* ControladorProductos::obtenerProducto(DTProductoCN producto){
    map<int,Producto*>:: iterator it = ColeccionProds.begin();
    Producto* actual = it->second;
    while(to_string(actual->getCodigo())!=producto.getCodigo() && it!= ColeccionProds.end() ){
        it++;
        actual = it->second;
        }
    return it->second;
    
}

set<DTProducto> ControladorProductos:: obtenerListaProdsPendientes(string nick){
   set<DTProducto> ret = {};
   map<int,Producto*>:: iterator it = ColeccionProds.begin();
   
   for (it; it != ColeccionProds.end();++it){
    Producto* actual = it->second;
    if (actual->ProductoPendiente(nick)){
        DTProducto prod(actual->getNombre(),actual->getDescripcion(),to_string(actual->getCodigo()),actual->getPrecio(),actual->getStock(),actual->getCategoria());
        ret.insert(prod);
    }
   }
    return ret;
}

 set<CompraProducto*> ControladorProductos::ObtenerProductos(set <ParCodCant> cc){
    set<CompraProducto*> res;
    set<ParCodCant>::iterator it;
    for (it = cc.begin(); it != cc.end();++it){
        Producto* p = ColeccionProds[(*it).getCodigo()];
        CompraProducto* cp = new CompraProducto(false, (*it).getCantidad(), nullptr, p);
        p->setCompraProd(cp);
        res.insert(cp);
    }
    return res;
}

set<DTProducto> ControladorProductos::productosDelVendedor(string nickname){
    set<DTProducto> ProdsDeVend = {};
    map<int,Producto*>::iterator it = ColeccionProds.begin();
    for(it;it!=ColeccionProds.end();it++){
        Usuario* vend = it->second->getVendedor();
        if(vend->getNickname() == nickname)
            ProdsDeVend.insert(it->second->getDTProducto());
    }
    return ProdsDeVend;
}

bool ControladorProductos::estaEnPromoVigente(int cod){
    bool esta = false;
    FechaAct* IFactual = FechaAct::getInstancia();
    DTFecha Facutal = IFactual->getDTFecha();
        Producto* prod = ColeccionProds[cod];
        if (prod != nullptr && prod->getPromProd()!=nullptr){
            Promocion* promo = prod->getPromProd()->getPromocion();
            esta = Facutal < promo->getFechaVenc();
        }
    return esta;
}
