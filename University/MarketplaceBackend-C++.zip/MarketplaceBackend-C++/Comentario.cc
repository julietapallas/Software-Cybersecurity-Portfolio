#include "Comentario.hh"

Comentario::Comentario(string t,DTFecha f,int id):Fecha(f){
    Texto = t;
    Fecha = f;
    ID=id;
};

Comentario::~Comentario(){};

void Comentario::setID(int id){
    ID=id;
}

int Comentario::getID(){
    return ID;
} 
    
void Comentario::setTexto(string texto){
    Texto=texto;
};
    
void Comentario::setFecha(DTFecha fecha){
    Fecha=fecha;
};
    
void Comentario::setProductoComentado(Producto* productocomentado){
ProductoComentado=productocomentado;
};
    
void Comentario::setRespuesta(Comentario* respuesta){
    Respuestas.insert(respuesta);
};

void Comentario::setRespuestas(set<Comentario*> respuestas){
    Respuestas=respuestas;
};

void Comentario::setRealizaCom(Usuario* u){
    realizaCom = u;
};

void Comentario::setRespondeA(Comentario* c){
    respondeA = c;
}
    
string Comentario::getTexto(){
    return Texto;
};
    
DTFecha Comentario::getFecha(){
    return Fecha;
};
    
Producto* Comentario::getProductoComentado(){
    return ProductoComentado;
};
    
set<Comentario*> Comentario::getRespuestas(){
    return Respuestas;
};

Usuario* Comentario::getRealizaCom(){
    return realizaCom;
}

Comentario* Comentario::getRespondeA(){
    return respondeA;
}

void Comentario::eliminarRespuestas() {
    set<Comentario*>::iterator it;
    for (it = Respuestas.begin(); it != Respuestas.end(); it++) {
            (*it)->eliminarRespuestas();
            Usuario* u = (*it)->getRealizaCom();
            u->eliminarComentario(*it);
            delete *it;
    }
    Respuestas.clear();
    
};

void Comentario::eliminarRespuesta(Comentario* c){
    Respuestas.erase(c);
}

DTComentario Comentario::getDTComentario(){
    return DTComentario(Texto, Fecha,ID);
};