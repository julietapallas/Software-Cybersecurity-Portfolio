#ifndef _VENDEDOR_HH_
#define _VENDEDOR_HH_
#include "Usuario.hh"
#include "DT.hh"
#include <set>
#include <string>
class Cliente;
class Vendedor: public Usuario {
private:
    string codigoRUT;
public:
    //CREADOR, DESTRUCTOR, GETTERS Y SETTERS
    Vendedor(string nick, string contr, string RUT, DTFecha FN);
    ~Vendedor();
    string getCodigoRUT();
    void setCodigoRUT(string RUT);
    DTVendedor getDTVendedor();
    DTExpU* obtenerExpediente();
};
#endif