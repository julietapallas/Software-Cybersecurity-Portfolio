#include "Promocion.hh"

Promocion :: Promocion(string N, string Descr, float Descu, DTFecha FV, set<PromocionProducto*> colecc):FechaVenc(FV){
    Nombre = N;
    Descripcion = Descr;
    Descuento = Descu;
    ColeccionPromProds = colecc;
}

Promocion:: ~Promocion(){

}

void Promocion::setNombre(string N){
    Nombre = N;
}

void Promocion::setDescripcion(string Descr){
    Descripcion = Descr;
}

void Promocion::setDescuento(float Descu){
    Descuento = Descu;
}

void Promocion::setFechaVenc(DTFecha FV){
    FechaVenc = FV;
}

void Promocion::Asociar(PromocionProducto* PromProd){
    ColeccionPromProds.insert(PromProd);
}

string Promocion::getNombre(){
    return Nombre;
}

string Promocion::getDescripcion(){
    return Descripcion;
}

float Promocion::getDescuento(){
    return Descuento;
}

DTFecha Promocion::getFechaVenc(){
    return FechaVenc;
}

set<PromocionProducto *> Promocion::getColeccionPromProds(){
    return ColeccionPromProds;
}

DTPromocion Promocion::getDTPromocion(){
    DTPromocion DataPromo(Nombre,Descripcion,Descuento,FechaVenc);
    return DataPromo;
};

DTProm Promocion::getDTProm(){
    set<PromocionProducto*>::iterator it = ColeccionPromProds.begin();
    PromocionProducto* primero;
    PromocionProducto* iter;
    primero = *it;
    set<DTProd> productos = {};
    for(it;it != ColeccionPromProds.end();it++){
        iter = *it;
        productos.insert(iter->getDTProd());
    }
    DTProm res(primero->getDTVendedor(),productos);
    return res;
}

bool Promocion::hechaPorVend(string nickname){
    set<PromocionProducto*>::iterator it = ColeccionPromProds.begin();
    PromocionProducto* pp = *it;
    return pp->hechaPorVend(nickname);
}
