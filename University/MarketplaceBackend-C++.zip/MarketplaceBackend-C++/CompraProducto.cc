
#include "CompraProducto.hh"

CompraProducto::CompraProducto(bool e, int CP, Compra *c, Producto *p){
    Enviado =e;
    CantProd = CP;
    compra = c;
    producto = p;
}
CompraProducto::~CompraProducto(){
}

void CompraProducto::setEnviado(bool e){
    Enviado = e;
}
void CompraProducto::setCantProd(int CP){
    CantProd = CP;
}
void CompraProducto::setCompra(Compra *c){
    compra = c;
}
void CompraProducto::setProducto(Producto *p){
    producto = p;
}

bool CompraProducto::getEnviado(){
    return Enviado;
}

int CompraProducto::getCantProd(){
    return CantProd;
}

Compra *CompraProducto::getCompra(){
    return compra;
}

Producto *CompraProducto::getProducto(){
    return producto;
}
