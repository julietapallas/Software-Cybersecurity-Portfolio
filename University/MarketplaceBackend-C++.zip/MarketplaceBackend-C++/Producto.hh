#ifndef __Producto__HH__
#define __Producto__HH__
#include <vector>
#include "DT.hh"
#include "Usuario.hh"
#include "CompraProducto.hh"
#include "PromocionProducto.hh"

class Comentario;
class PromocionProducto;
class Usuario;
class Producto{
    private:
        string Nombre, Descripcion;
        float Precio;
        int Stock,Codigo;
        DTCategoria Categoria;
        PromocionProducto *PP; 
        vector<CompraProducto*> CP; 
        Usuario* Vendedor;
        set<Comentario*> ComentariosRealizados;
    public: 
        Producto(string N,float P, int S, string Desc, DTCategoria Cat, int Cod, Usuario* vend, PromocionProducto* promoprod, vector<CompraProducto*> compras);
        ~Producto();
       
        DTProducto getDTProducto();
        int getStock();
        float getPrecio();
        string getNombre();
        int getCodigo(); 
        string getDescripcion();
        DTCategoria getCategoria();
        PromocionProducto* getPromProd();
        Usuario* getVendedor();

        void setNombre(string N);
        void setDescripcion(string Desc);
        void setCodigo(int Cod);
        void setPrecio(float P);
        void setStock(int S);
        void setCategoria(DTCategoria Cat);
        void setPromProd(PromocionProducto*pp);
        void setCompraProd(CompraProducto *cp);
        void setVendedor(Usuario* vendedor);

        void setComentario(Comentario * nuevocoment);
        void setComentariosRealizados(set<Comentario*> cr);
        void eliminarComentario(DTComentario aEliminar);
        set<Comentario*> getComentariosRealizados();
        set<DTComentario> obtenerComentarios();

        void Asociar(PromocionProducto *  pp);
        void Asociar(CompraProducto * cp);
        bool prodValido(string nick);
        bool ProductoPendiente(string nick);
};
#endif
