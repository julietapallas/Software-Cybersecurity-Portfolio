#ifndef __PromocionProducto__HH__
#define __PromocionProducto__HH__
#include "DT.hh"
#include"Producto.hh"
#include"Promocion.hh"
#include"Usuario.hh"

class Usuario;
class Producto;
class Promocion;


class PromocionProducto{
    private:
        int CantMin;
        Promocion * promocion;
        Producto * producto;

    public: 
        PromocionProducto(int CM, Promocion* promo, Producto*prod);
        ~PromocionProducto();

        DTFecha getFecha();
        int getCantMin();
        Promocion *getPromocion();
        Producto * getProducto();

        void setCantMin(int CM);
        void setProducto(Producto * prod);
        void setPromocion(Promocion * prom);

    
        float ObtenerDescuento();
        bool correspondeCantMin(int);
        DTVendedor getDTVendedor();
        DTProd getDTProd();
        bool hechaPorVend(string nickname);
};
#endif
