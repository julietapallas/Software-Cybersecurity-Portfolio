#ifndef _CLIENTE_HH_
#define _CLIENTE_HH_
#include "Usuario.hh"
#include "DT.hh"
#include <set>
#include <string>


class Cliente: public Usuario {
private:
    DTDireccion direccion;
    string ciudad;
    set<DTNotificacion> notificaciones;
public:
    //CREADOR, DESTRUCTOR, GETTERS Y SEYYERS
    Cliente(string nick, string cont, string ciud, DTFecha FN, DTDireccion dir, set<DTNotificacion> notif);
    ~Cliente();
    string getCiudad();
    DTDireccion getDireccion();
    set<DTNotificacion> getNotificaciones();
    void setCiudad(string ciud);
    void setDireccion(DTDireccion dir);
    void setNotificaciones(set<DTNotificacion> notif);

    //INTERACCIONES 
    void obtenerNotificaciones();
    void notificar(string, string, set<DTProducto>);
    set<DTVendedor*> vendedoresAsociados();
    void eliminarNotificaciones();
    DTExpU* obtenerExpediente();
};
#endif
