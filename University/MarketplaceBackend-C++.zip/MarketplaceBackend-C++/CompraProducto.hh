#ifndef __COMPRAPRODUCTO__HH
#define __COMPRAPRODUCTO__HH

class Compra;
class Producto;

class CompraProducto {
    private:
        bool Enviado;
        int CantProd;
        Compra* compra;
        Producto* producto;
    public:
        CompraProducto(bool e, int CP, Compra* c, Producto* p);//los punteros van en el contructor?
        ~CompraProducto();

        void setEnviado(bool e);
        void setCantProd(int CP);
        void setCompra(Compra* c);
        void setProducto(Producto* p);

        bool getEnviado();
        int getCantProd();
        Compra* getCompra();
        Producto* getProducto();
};
#endif