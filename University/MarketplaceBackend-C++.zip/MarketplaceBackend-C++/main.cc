#include "Fabrica.hh"
#include <iostream>

IUsuarios* CUsuario = Fabrica::getContUsuarios();
IPromociones* CPromo = Fabrica::getContPromocion();
ICompras* CCompra = Fabrica ::getContCompras();
IProductos* CProd = Fabrica::getContProductos();

void CargarDatos(){

	FechaAct* fAct = FechaAct::getInstancia();
	DTFecha fechaAnt = fAct->getDTFecha();

//________________________________________________INGRESAR USUARIOS
	DTFecha f1(15,5,1988);
    DTFecha f2(18,6,1986);
    DTFecha f3(28,7,1993);
    DTFecha f4(20,10,1992);
    DTFecha f5(22,9,1979);
    DTFecha f6(25,3,1985);
    DTFecha f7(14,4,1982);
    DTFecha f8(30,11,1995);
    DTFecha f9(12,8,1990);
    DTFecha f10(7,12,1283);

    DTDireccion d4("Av. 18 de Julio",456);
    DTDireccion d5("Rondeau",1617);
    DTDireccion d7("Paysandu",2021);
    DTDireccion d8("Av. Rivera",1819);
    DTDireccion d9("Av. Brasil",1011);

    DTVendedor * US1 = new DTVendedor("ana23","qwer1234",f1,"212345678001");
    DTVendedor* US2 = new DTVendedor("carlos78","asdfghj",f2,"356789012345");
    DTVendedor* US3 = new DTVendedor("diegom","zxcvbn",f3,"190123456789");
    DTCliente* US4 = new DTCliente("juan87","1qaz2wsx",f4,d4,"Melo",{});
    DTCliente* US5 = new DTCliente("laura", "3edc4rf",f5,d5,"Montevideo",{});
    DTVendedor* US6 = new DTVendedor("maria01","5tgb6yhn",f6,"321098765432");
    DTCliente* US7 = new DTCliente("natalia", "poiuyt",f7,d7,"Salto",{});
    DTCliente* US8 = new DTCliente("pablo10","lkjhgv",f8,d8,"Mercedes",{});
    DTCliente* US9 = new DTCliente("roberto","mnbvcx",f9,d9,"Montevideo",{});
    DTVendedor* US10 = new DTVendedor("sofia25","1234asdf",f10,"445678901234");

    string resultado = CUsuario->ingresarUsuario(US1);
    resultado = CUsuario->ingresarUsuario(US2);
    resultado = CUsuario->ingresarUsuario(US3);
    resultado = CUsuario->ingresarUsuario(US4);
    resultado = CUsuario->ingresarUsuario(US5);
    resultado = CUsuario->ingresarUsuario(US6);
    resultado = CUsuario->ingresarUsuario(US7);
    resultado = CUsuario->ingresarUsuario(US8);
    resultado = CUsuario->ingresarUsuario(US9);
    resultado = CUsuario->ingresarUsuario(US10);




//________________________________________________INGRESAR PRODUCTOS

DTCategoria R = DTCategoria::Ropa;
DTCategoria E = DTCategoria::Electrodomestico;
DTCategoria O = DTCategoria::Otro;

DTProductoSinC PR1("Camiseta Azul","Camiseta de poliester, color azul",1400,50,R);
DTProductoSinC PR2("Televisor LED", "Televisor LED 55 pulgadas",40500,30,E);
DTProductoSinC PR3("Chaqueta de Cuero","Chaqueta de cuero, color negro",699.990,20,R);
DTProductoSinC PR4("Microondas Digital","Microondas Digital, 30L",1199.99,15,E);
DTProductoSinC PR5("Luz LED","Luz Bluetooth LED",599.990,40,O);
DTProductoSinC PR6("Pantalones Vaqueros","Pantalones Vaqueros, talla 32",60,25,R);
DTProductoSinC PR7("Auriculares Bluetooth","Auriculares bluetooth para celular",199.990,35,O);
DTProductoSinC PR8("Refrigerador","Refrigerador de doble puerta",15499,10,E);
DTProductoSinC PR9("Cafetera","Cafetera de goteo programable",23000,50,E);
DTProductoSinC PR10("Zapatillas Deportivas","Zapatillas para correr, talla 42",5500,20,R);
DTProductoSinC PR11("Mochila","Mochila de viaje, 40L",9000,30,O);
DTProductoSinC PR12("Plancha de Ropa","Plancha a vapor, 1500W",2534,25,E);
DTProductoSinC PR13("Gorra","Gorra para deportes, color rojo",200,50,R);
DTProductoSinC PR14("Tablet","Tablet Android de 10 pulgadas",15000,15,E);
DTProductoSinC PR15("Reloj de Pared","Reloj de pared vintage",150.50,20,O);


int res = CProd->ingresarProducto(PR1,US2->getNickname());
res = CProd->ingresarProducto(PR2,US1->getNickname());
res = CProd->ingresarProducto(PR3,US2->getNickname());
res = CProd->ingresarProducto(PR4,US1->getNickname());
res = CProd->ingresarProducto(PR5,US3->getNickname());
res = CProd->ingresarProducto(PR6,US2->getNickname());
res = CProd->ingresarProducto(PR7,US3->getNickname());
res = CProd->ingresarProducto(PR8,US1->getNickname());
res = CProd->ingresarProducto(PR9,US1->getNickname());
res = CProd->ingresarProducto(PR10,US2->getNickname());
res = CProd->ingresarProducto(PR11,US2->getNickname());
res = CProd->ingresarProducto(PR12,US3->getNickname());
res = CProd->ingresarProducto(PR13,US10->getNickname());
res = CProd->ingresarProducto(PR14,US3->getNickname());
res = CProd->ingresarProducto(PR15,US10->getNickname());





//________________________________________________INGRESAR PROMOCIONES

DTFecha fp1(25,10,2024);
DTFecha fp2(26,10,2024);
DTFecha fp3(26,10,2024);
DTFecha fp4(26,3,2024);

DTPromocion p1("Casa Nueva","Para que puedas ahorrar en la casa nueva",30,fp1);
DTPromocion p2("Fiesta","Para que no te quedes sin ropa para las fiestas",20,fp2);
DTPromocion p3("Domotica","Para modernizar tu casa",10,fp3);
DTPromocion p4("Liquidacion","Hasta agotar stock",10,fp4);

CPromo->ingresarPromo(p1);
ParCodCant pcc1(2,1);
ParCodCant pcc2(4,1);
ParCodCant pcc3(8,1);
set<DTProductoCN> pcn = CPromo->obtenerProductosVend("ana23");
bool sp1 = CPromo->selecProd(pcc1);
bool sp2 = CPromo->selecProd(pcc2);
bool sp3 = CPromo->selecProd(pcc3);
bool c1 =  CPromo->altaPromocion();


CPromo->ingresarPromo(p2);
ParCodCant pcc4(3,2);
ParCodCant pcc5(6,3);
pcn = CPromo->obtenerProductosVend("carlos78");
bool sp4 = CPromo->selecProd(pcc4);
bool sp5 = CPromo->selecProd(pcc5);
bool c2 =  CPromo->altaPromocion();


CPromo->ingresarPromo(p3);
ParCodCant pcc6(5,2);
pcn = CPromo->obtenerProductosVend("diegom");
bool sp6 = CPromo->selecProd(pcc6);
bool c3 =  CPromo->altaPromocion();


CPromo->ingresarPromo(p4);
ParCodCant pcc7(14,1);
pcn = CPromo->obtenerProductosVend("diegom");
bool sp7 = CPromo->selecProd(pcc7);
bool c4 =  CPromo->altaPromocion();





//________________________________________________INGRESAR COMPRAS

FechaAct* fecha = FechaAct::getInstancia();

fecha->setDia(1);
fecha->setMes(5);
fecha->setAnio(2024);

set<DTProducto> productos = CCompra->elegirCliente(US4->getNickname());
CCompra->ingresarProducto(2,2);
CCompra->ingresarProducto(4,1);
CCompra->ingresarProducto(8,1);
ParCompraProductos pcp1 = CCompra->obtenerDatosCompra();

vector<ParClienteCompra> pendientes = CCompra->ObtenerComprasPendientes(2);
CCompra->CompraProdEnviada(0);


productos = CCompra->elegirCliente(US4->getNickname());
CCompra->ingresarProducto(5,1);
ParCompraProductos pcp2 = CCompra->obtenerDatosCompra();

pendientes = CCompra->ObtenerComprasPendientes(5);
CCompra->CompraProdEnviada(1);
fecha->setDia(15);


productos = CCompra->elegirCliente(US5->getNickname());
CCompra->ingresarProducto(14,10);
ParCompraProductos pcp3 = CCompra->obtenerDatosCompra();

pendientes = CCompra->ObtenerComprasPendientes(14);
CCompra->CompraProdEnviada(2);

fecha->setDia(25);
fecha->setMes(4);

productos = CCompra->elegirCliente(US7->getNickname());
CCompra->ingresarProducto(11,1);
CCompra->ingresarProducto(12,1);
CCompra->ingresarProducto(13,1);
ParCompraProductos pcp4 = CCompra->obtenerDatosCompra();

pendientes = CCompra->ObtenerComprasPendientes(11);
CCompra->CompraProdEnviada(3);
pendientes = CCompra->ObtenerComprasPendientes(12);
CCompra->CompraProdEnviada(3);
pendientes = CCompra->ObtenerComprasPendientes(13);
CCompra->CompraProdEnviada(3);

fecha->setDia(20);
fecha->setMes(5);


productos = CCompra->elegirCliente(US4->getNickname());
CCompra->ingresarProducto(3,2);
CCompra->ingresarProducto(6,3);
ParCompraProductos pcp5 = CCompra->obtenerDatosCompra();

pendientes = CCompra->ObtenerComprasPendientes(6);
CCompra->CompraProdEnviada(4);

fecha->setDia(12);


productos = CCompra->elegirCliente(US5->getNickname());
CCompra->ingresarProducto(1,2);
ParCompraProductos pcp6 = CCompra->obtenerDatosCompra();

fecha->setDia(13);


productos = CCompra->elegirCliente(US7->getNickname());
CCompra->ingresarProducto(1,3);
ParCompraProductos pcp7 = CCompra->obtenerDatosCompra();

pendientes = CCompra->ObtenerComprasPendientes(1);
CCompra->CompraProdEnviada(6);

fecha->setDia(14);


productos = CCompra->elegirCliente(US8->getNickname());
CCompra->ingresarProducto(1,4);
ParCompraProductos pcp8 = CCompra->obtenerDatosCompra();

fecha->setDia(15);


productos = CCompra->elegirCliente(US9->getNickname());
CCompra->ingresarProducto(1,5);
ParCompraProductos pcp9 = CCompra->obtenerDatosCompra();




//________________________________________________INGRESAR COMENTARIOS

fecha->setDia(1);
fecha->setMes(6);
fecha->setAnio(2024);

set<DTProductoCN> prods = CUsuario->obtenerProductos(US4->getNickname());
DTProductoCN prodCN1(PR1.getNombre(),"1");
CUsuario->selecProd(prodCN1);
CUsuario->AgregarComentario("¿La camiseta azul está disponible en talla M?");


prods = CUsuario->obtenerProductos(US2->getNickname());
CUsuario->selecProd(prodCN1);
CUsuario->AgregarRespuesta("Si, tenemos la camiseta azul en talla M.",1);

fecha->setDia(2);

prods = CUsuario->obtenerProductos(US5->getNickname());
CUsuario->selecProd(prodCN1);
CUsuario->AgregarRespuesta("¿Es de buen material? Me preocupa la durabilidad.",2);

prods = CUsuario->obtenerProductos(US4->getNickname());
CUsuario->selecProd(prodCN1);
CUsuario->AgregarRespuesta("He comprado antes y la calidad es buena",3);

prods = CUsuario->obtenerProductos(US7->getNickname());
CUsuario->selecProd(prodCN1);
CUsuario->AgregarComentario("¿Como es el ajuste?¿Es ajustada o holgada?");

prods = CUsuario->obtenerProductos(US5->getNickname());
DTProductoCN prodCN2(PR2.getNombre(),"2");
CUsuario->selecProd(prodCN2);
CUsuario->AgregarComentario("¿Cual es la resolucion del Televisor LED?");

prods = CUsuario->obtenerProductos(US1->getNickname());
CUsuario->selecProd(prodCN2);
CUsuario->AgregarRespuesta("El Televisor LED tiene una resolución de 4k UHD.",6);

fecha->setDia(3);

prods = CUsuario->obtenerProductos(US8->getNickname());
CUsuario->selecProd(prodCN2);
CUsuario->AgregarComentario("¿Tiene soporte para HDR10?");

prods = CUsuario->obtenerProductos(US1->getNickname());
CUsuario->selecProd(prodCN2);
CUsuario->AgregarRespuesta("Si, soporta HDR10.",8);

prods = CUsuario->obtenerProductos(US7->getNickname());
DTProductoCN prodCN3(PR3.getNombre(),"3");
CUsuario->selecProd(prodCN3);
CUsuario->AgregarComentario("¿La chaqueta de cuero es resistente al agua?");

prods = CUsuario->obtenerProductos(US2->getNickname());
CUsuario->selecProd(prodCN3);
CUsuario->AgregarRespuesta("No, la chaqueta de cuero no es resistente al agua",10);

fecha->setDia(4);

prods = CUsuario->obtenerProductos(US5->getNickname());
CUsuario->selecProd(prodCN3);
CUsuario->AgregarRespuesta("¿Viene en otros colores?",10);

prods = CUsuario->obtenerProductos(US2->getNickname());
CUsuario->selecProd(prodCN3);
CUsuario->AgregarRespuesta("Si, tambien esta disponible en marron",12);

prods = CUsuario->obtenerProductos(US9->getNickname());
CUsuario->selecProd(prodCN3);
CUsuario->AgregarRespuesta("¿Es aduecuada para climas frios?",10);

prods = CUsuario->obtenerProductos(US8->getNickname());
DTProductoCN prodCN4(PR4.getNombre(),"4");
CUsuario->selecProd(prodCN4);
CUsuario->AgregarComentario("¿El Microondas digital tiene funcion de descongelacion rapida?");

prods = CUsuario->obtenerProductos(US1->getNickname());
CUsuario->selecProd(prodCN4);
CUsuario->AgregarRespuesta("Si, el microondas digital incluye una funcion de descongelacion reapida.",15);

fecha->setDia(5);

prods = CUsuario->obtenerProductos(US7->getNickname());
CUsuario->selecProd(prodCN4);
CUsuario->AgregarRespuesta("¿Cuantos niveles de potencia tiene?",15);

prods = CUsuario->obtenerProductos(US1->getNickname());
CUsuario->selecProd(prodCN4);
CUsuario->AgregarRespuesta("Tiene 10 niveles de potencia",17);


prods = CUsuario->obtenerProductos(US9->getNickname());
CUsuario->selecProd(prodCN4);
CUsuario->AgregarRespuesta("¿Es facil de limpiar?",15);

prods = CUsuario->obtenerProductos(US9->getNickname());
DTProductoCN prodCN5(PR5.getNombre(),"5");
CUsuario->selecProd(prodCN5);
CUsuario->AgregarComentario("¿La luz LED se puede controlar con una aplicacion movil?");

prods = CUsuario->obtenerProductos(US3->getNickname());
CUsuario->selecProd(prodCN5);
CUsuario->AgregarRespuesta("Si, la luz Led se puede controlar a travez de un aplicacion movil",20);

fecha->setDia(6);

prods = CUsuario->obtenerProductos(US8->getNickname());
CUsuario->selecProd(prodCN5);
CUsuario->AgregarRespuesta("¿Es compatible con Alexa o Google Home?",20);

prods = CUsuario->obtenerProductos(US3->getNickname());
CUsuario->selecProd(prodCN5);
CUsuario->AgregarRespuesta("Si, es compatible con ambos",22);

prods = CUsuario->obtenerProductos(US7->getNickname());
CUsuario->selecProd(prodCN5);
CUsuario->AgregarRespuesta("¿Cuanto dura la bateria?",20);

fecha->setDia(6);

prods = CUsuario->obtenerProductos(US8->getNickname());
CUsuario->selecProd(prodCN5);
CUsuario->AgregarRespuesta("¿La aplicacion movil es facil de usar?",20);



//_________________________________ Volver a la fecha anterior

	fAct->setDia(fechaAnt.getDia());
	fAct->setMes(fechaAnt.getMes());
	fAct->setAnio(fechaAnt.getAnio());

}



int main(){

	int dia, mes, anio;
	FechaAct* fechaActual = FechaAct::getInstancia();
	

	int cu;
	int seguir = 1;
	while(seguir == 1){
		
		cout << "\nLos casos de uso son: " << endl << "1: Alta de usuario" << endl << "2: Listado de usuarios" << endl << "3: Alta de producto" << endl << "4: Consultar producto" << endl << "5: Crear promoción" << endl << "6: Consultar promoción" << endl << "7: Realizar compra" << endl << "8: Dejar comentario" << endl << "9: Eliminar comentario" << endl << "10: Enviar producto" << endl << "11: Expediente de Usuario" << endl << "12: Suscribirse a notificaciones" << endl << "13: Consulta de notificaciones" << endl << "14: Eliminar suscripciones" << endl << "15: Establecer fecha actual" << endl <<"16: Cargar datos de prueba"<<endl;
		cout << "\nIngrese el número del caso de uso que quiere realizar: " <<endl;
		cin >> cu;
		cin.ignore();
		switch(cu){
			case 1:{// Alta de usuario
				string nick, contra, cv, resultado;
				int diaNac, mesNac, anioNac;
				cout << "\nIngrese los datos del usuario que quiere dar de alta:" << endl;
				
				cout << "\nNickname:" << endl;
				getline(cin, nick);
				cout << "\nContraseña (de al menos 6 caracteres):" << endl;
				getline(cin, contra);
				if(contra.length() >= 6){
					cout << "\nFecha de nacimiento:" << endl;
					cout << "\nDía:" << endl;
					cin >> diaNac;
					cout << "\nMes:" << endl;
					cin >> mesNac;
					cout << "\nAño:" << endl;
					cin >> anioNac;
					DTFecha FNac(diaNac, mesNac, anioNac);

					cout << "\n¿Es un ciente o vendedor? (c/v)" << endl;
					cin >> cv;
					cin.ignore();
					if(cv == "c"){
						string  calle, ciudad;
						int numPuerta;
						cout << "\nIngrese la dirección del cliente:" << endl;
						cout << "\nCalle:" << endl;
						getline(cin, calle);
						cout << "\nNúmero de Puerta:" <<endl;
						cin >> numPuerta;
						cin.ignore();
						cout << "\nCiudad:" <<endl;
						getline(cin, ciudad);
						DTDireccion Dir(calle, numPuerta);
						DTCliente* Cl = new DTCliente(nick, contra, FNac, Dir, ciudad, {});//libero memoria?
						resultado = CUsuario->ingresarUsuario(Cl);
						cout << "\n" << resultado << endl;
					}else if(cv == "v"){
						string RUT;
						cout << "\nIngresar el código RUT del vendedor (de 12 caracteres):" << endl;
						cin >> RUT;
						cin.ignore();
						if(RUT.length() == 12){
							DTVendedor* Vend = new DTVendedor(nick, contra, FNac, RUT);
							resultado = CUsuario->ingresarUsuario(Vend);
							cout << "\n" << resultado << endl;	
						}else cout << "\nEl código ingresado no es de 12 caracteres." << endl;
						
					}else{
						cout << "\nLa opción ingresada no es válida." << endl;
					}
				}else cout << "\nLa contraseña ingresada tiene menos de 6 caracteres." << endl;
				break;
			}
			case 2:{// Listado de usuarios
				set<DTUsuario*> us = CUsuario->consultarInfoUsuario();
				cout << "\nLos usuarios ingresados en el sistema son:\n" << endl << endl;;
				set<DTUsuario*>::iterator iu;
				for(iu = us.begin(); iu != us.end(); ++iu){
					cout << (*iu)->toString();
					cout << endl;
				}
				break;
			}
			case 3:{// Alta de producto
				set<string> nv = CProd->obtenerVendedores();
				set<string>::iterator inv;
				cout << "\nLos nicknames de los vendedores ingresados al sistema son:\n"<< endl;
				for(inv = nv.begin(); inv != nv.end(); ++inv){
					cout << (*inv) << endl;
				}
				string nick, nombre, descripcion;
				float precio;
				int stock, categoria;
				cout << "\nEscriba el nickname del vendedor que quiera seleccionar:" << endl;
				getline(cin, nick);
				if (nv.find(nick) != nv.end()){
					cout << "\nIngrese los datos del producto que desea dar de alta:" << endl;
					cout << "\nNombre:" << endl;
					getline(cin, nombre);
					cout << "\nDescripción:" << endl;
					getline(cin, descripcion);
					cout << "\nPrecio:" << endl;
					cin >> precio;
					cout << "\nStock:" << endl;
					cin >> stock;
					cout << "\nCategoría (1 Ropa, 2 Electrodomestico, 3 Otro, ingrese el número):" << endl;
					cin >> categoria;
					cin.ignore();
					DTCategoria cat;
					bool catFin = true;
					while(catFin){
						switch(categoria){
							case 1:{
								cat = DTCategoria::Ropa;
								catFin = false;
								break;
							}
							case 2:{
								cat = DTCategoria::Electrodomestico;
								catFin = false;
								break;
							}
							case 3:{
								cat = DTCategoria::Otro;
								catFin = false;
								break;
							}
							default: {cout << "\nLa opción ingresada no es correcta\n\nCategoría (1 Ropa, 2 Electrodomestico, 3 Otro, ingrese el número):" << endl;
									cin >> categoria;
									break;
							}
						}
					}
					DTProductoSinC  dtp(nombre, descripcion, precio, stock, cat);
					int cod = CProd->ingresarProducto(dtp, nick);
					cout << "\nCódigo asignado: " << cod << endl;
				}else{
					cout << "\nNo existe en el sistema un vendedor con el nickname ingresado."<<endl;
				}
				break;
			}
			case 4:{// Consultar producto
				set<DTProductoCN> lp = CProd->ObtenerListaProductos();
				cout << "\nLos productos en el sistema son:\n" << endl;
				set<DTProductoCN>::iterator ilp;
				for(ilp = lp.begin(); ilp != lp.end(); ++ilp){
					cout << (*ilp).toString();
					cout << endl;
				} 
				cout << "Ingresar el código del producto elegido:" << endl;
				int codigo;
				cin >> codigo;
				cin.ignore();
				bool prodValido = false;
				for (ilp = lp.begin(); (ilp != lp.end()) && (!prodValido); ++ilp){
					prodValido = ((*ilp).getCodigo() == to_string(codigo));

				}
				if (prodValido){
				ParVendedorProducto parvp = CProd->mostrarProducto(codigo);
				cout << "\nLos datos del producto selccionado son:\n" << endl;
				cout << parvp.getProducto().toString();
				cout << "Nickname del vendedor: " << parvp.getNickVendedor() << endl;
				}else{
					cout << "\nEl código ingresado no es válido"<< endl;
				}
				
				break;
			}
			case 5:{// Crear promoción
				string nombre, descripcion, nickv;
				float descuento;
				int diap, mesp, aniop;
				cout << "\nIngresar los datos de la promoción que quiere crear:" << endl;
				cout << "\nNombre:" << endl;
				getline(cin, nombre);
				cout << "\nDescripción:" << endl;
				getline(cin, descripcion);
				cout << "\nDescuento:" << endl;
				cin >> descuento;
				cout << "\nFecha de vencimiento:" << endl;
				cout << "\nDía:" << endl;
				cin >> diap;
				cout << "\nMes:" << endl;
				cin >> mesp;
				cout << "\nAño:" << endl;
				cin >> aniop;
				DTFecha FVenc(diap, mesp, aniop);
				DTPromocion Promo(nombre,descripcion, descuento, FVenc);
				CPromo->ingresarPromo(Promo);
				cout << "\nLos nicknames de los vendedores ingresados al sistema son:\n" << endl;
				set<string> nvend = CPromo->obtenerVendedores();
				set<string>::iterator invend;
				for(invend = nvend.begin(); invend != nvend.end(); ++invend){
					cout << (*invend) << endl;
				}
				cout << "\nIngrese el nickname del vendedor del cual quiera ver sus productos:" << endl;
				cin >>nickv;
				if (nvend.find(nickv) != nvend.end()){
					set<DTProductoCN> prodsv = CPromo->obtenerProductosVend(nickv);
					if(prodsv.empty()){
						cout << "\nEl vendedor ingresado no tiene productos" << endl;
						}
					else{
					cout << "\nLos productos del vendedor disponibles para agregar a una promoción son:\n" << endl;
					set<DTProductoCN>::iterator iprodsv;
					for(iprodsv = prodsv.begin(); iprodsv != prodsv.end(); ++iprodsv){
						cout << (*iprodsv).toString();
						cout << endl;
					} 
					bool seguir = true;
					int cod;
					int cantMin;
					string s;
					cout << "Ingrese los datos de los productos que quiere agregar:" << endl;
					while(seguir){
						cout << "\nIngresar el Código:" << endl;
						cin >> cod;
						cout << "\nIngresar la cantidad mínima requerida para poder aplicar la promoción:" << endl;
						cin >> cantMin;
						ParCodCant par(cod, cantMin);
						bool selec = CPromo->selecProd(par);//no lo uso porque ya lo chequeaste??
						if (!selec){
							cout << "\nEl codigo ingresado en inválido"<< endl;
						}
						cout << "\n¿Quiere seguir agregando? (Si/No)" << endl;
						cin >> s;
						if(s != "Si"){
							seguir = false;
						}
					}
					bool promoCreada = CPromo->altaPromocion();
					if (promoCreada){
						cout << "\nLa promoción fue creada con éxito" << endl;
					}else{
						cout << "\nLa promoción no fue creada" << endl;
					}
					}
					}
				else{
					cout << "\nNo existe en el sistema un vendedor con el nickname ingresado."<< endl;
				}
				cin.ignore();
				break;
			}
			case 6:{// Consultar promoción
				set<DTPromocion> promosvigentes = CPromo->IniciarConsulta();
				cout << "\nLas promociones vigentes son:\n" <<endl;
				vector<DTPromocion> vectorPromos;
				int cont = 0;
				set<DTPromocion>::iterator ipv;
				for(ipv = promosvigentes.begin(); ipv != promosvigentes.end(); ++ipv){
					vectorPromos.push_back(*ipv);
					cout << cont << ": " << endl;
					cont++;
					cout << (*ipv).toString();
					cout << endl;
				}
				cout << "¿Desea ver más sobre una promoción en particular? (Si/No):" <<endl;
				string ver;
				cin >> ver;
				if(ver == "Si"){
					cout << "\nIngrese el número de la promoción que desea ver:" << endl;
					int verp;
					cin >> verp;
					if (verp >= vectorPromos.size() || verp < 0){
						cout << "\nEl numero seleccionado no es valido."<< endl; 
					}else{
						DTProm promo = CPromo->DatosPromocion(vectorPromos[verp]);
						cout << "\nInformación del vendedor de la promoción:\n" << endl;
						promo.getVendedor().toString();
						cout << "\nInformación de los productos de la promoción:\n"<< endl;;
						set<DTProd> prodsp = promo.getProdDeProm();
					set<DTProd>::iterator ipp;
						for(ipp = prodsp.begin(); ipp != prodsp.end(); ++ipp){
							cout << (*ipp).toString();
							cout << endl;
						}
					}		
				}
				vectorPromos.clear();
				cin.ignore();
				break;
			}
			case 7:{//Realizar Compra
				set<string> nombreClientes = CCompra->obtenerListaClientes();
				cout << "Los nombres de los clientes del sistema son:"<< endl << endl;
				for (set<string> :: iterator itnC = nombreClientes.begin(); itnC != nombreClientes.end(); ++itnC){
					cout << (*itnC)<<endl;
				}
				cout << "\nIngrese el Nickname del cliente elegido: " <<endl;
				string nick;
				getline(cin, nick);
				if (nombreClientes.find(nick) != nombreClientes.end()){
					set<DTProducto> LP = CCompra->elegirCliente(nick);
					cout << "\nLista de todos los productos del sistema:" << endl << endl;
					for(set<DTProducto>:: iterator j = LP.begin(); j != LP.end(); j++){
						cout << (*j).toString();
						cout << endl;
						cout << endl;
					}
					bool seguir = true;
					int cod;
					int cant;
					string s;
					cout <<"\nIngrese los datos de los productos que desa comprar:" << endl;
					while(seguir){
						cout << "\nIngresar el Código:" << endl;
						cin >> cod; 
						cout << "\nIngresar la cantidad de unidades a comprar:" << endl;
						cin >> cant;
						bool codValido = false;
						for (set<DTProducto> :: iterator it = LP.begin(); it != LP.end() && !codValido; ++it){
							codValido = ((*it).getCodigo() == to_string(cod));
						}
						bool ingresoValido = false;
						if (codValido){
							ingresoValido = CCompra->ingresarProducto(cod, cant);
							if (!ingresoValido){
								cout << "\nEl producto no puede ser ingresado"<< endl;
							}
						}else{
							cout << endl << "El código ingresado no corresponde a un producto válido" << endl;
						}
						
						cout << "\n¿Quiere seguir comprando? (Si/No)" <<endl;
						cin >> s;
						if(s != "Si"){
						seguir = false;
						}
					}
					ParCompraProductos par = CCompra->obtenerDatosCompra();
					if (par.getCompra().getPrecio() != 0){
						cout << "\nSe ha realizado la compra"<< endl;
						cout << par.getCompra().toString();
						cout << endl;
						set<DTProducto> prods = par.getProductos();
						set<DTProducto>::iterator it;
						for(it = prods.begin(); it!=prods.end();++it){
							cout << (*it).toString();
						}
					}else{
						cout << "\nNo se ha realizado la compra" << endl;
					}
					
				}else{
					cout << "\nNo existe en el sistema un cliente con el nickname ingresado"<< endl;
				}
				break;

			}
			case 8:{// Dejar comentario
				cout << "\nLos nicknames de los usuarios ingresados en el sistema son:\n" << endl;
				set<string> usuarios = CUsuario->obtenerUsuarios();
				set<string>::iterator iu;
				for(iu = usuarios.begin(); iu != usuarios.end();++iu){
					cout << (*iu) << endl;
				}
				cout << "\nIngresar el nickname del usuario elegido:" << endl;
				string nick;
				getline(cin, nick);
				if (usuarios.find(nick) != usuarios.end()){
					set<DTProductoCN> prods = CUsuario->obtenerProductos(nick);
					if(prods.empty()){
						cout << "\nNo existen productos en el sistema" << endl;
					}else{
						cout << "\nLos productos ingresados en el sistema son:" << endl;
						set<DTProductoCN>::iterator ip;
						for(ip = prods.begin();ip != prods.end(); ++ip){
							cout <<(*ip).toString();
							cout << endl;
						}
						int cod, com;
						string nom, texto;
						cout << "Ingrese el código del producto que quiere comentar:" << endl;
						cin >> cod;
						bool prodEncontrado = false;
						for (ip = prods.begin(); ip != prods.end() && !prodEncontrado ; ip++){
							prodEncontrado = (to_string(cod) == (*ip).getCodigo());
							if (prodEncontrado){
								nom = (*ip).getNombre();
							}
						}
						if (prodEncontrado){
							DTProductoCN Pcn(nom,to_string(cod));
							CUsuario->selecProd(Pcn);
							cout << "\nSi quiere ingresar un comentario nuevo ingrese 1, si quiere responder a uno ya existente ingrese 2:"<<endl;
							cin >> com;
							if(com==1){
								cout << "\nIngrese el texto del comentario:" << endl;
								cin.ignore();
								getline(cin, texto);
								CUsuario->AgregarComentario(texto);
							}else if (com == 2){
								set<DTComentario> coms = CUsuario->obtenerListaComentarios();
								if(!coms.empty()){
									set<DTComentario>::iterator ic; 
									for(ic = coms.begin(); ic != coms.end(); ++ic){
										cout << endl;
										cout << (*ic).toString();
									}
									cout << "\nIngrese el identificador del comentario que desea responder:" << endl;
									int id;
									cin >> id;
									cin.ignore();
									bool idEncontrado = false;
									for (ic = coms.begin(); ic != coms.end() && !idEncontrado; ic++){
										idEncontrado = (id == (*ic).getID());
									}
									if (idEncontrado){
										cout << "\nIngrese el texto de la respuesta:" << endl;
										getline(cin, texto);
										CUsuario->AgregarRespuesta(texto,id);
									}else{
										cout << "\nEl id ingresado no es válido."<< endl;
									}

								}else{
									cout << "\nNo existen comentarios para responder."<< endl;
								}
							}else{
								cout << "\nNo se ha ingresado una opción válida."<<endl;
							}
						}else{
							cout << "\nEl código ingresado no corresponde a un producto válido."<<endl;
						}
					}
				}else{
					cout << "\nNo existe en el sistema un usuario con el nickname ingresado."<< endl;
				}
				break;
			}
			case 9:{//Eliminar Comentario
				set<string> nombresUsuarios = CUsuario->obtenerListaNicknames();
				cout << "\nLos nicknames de los usuarios ingresados en el sistema son:" << endl;
				for (set<string>:: iterator it = nombresUsuarios.begin(); it != nombresUsuarios.end(); ++it ){
					cout << (*it) << endl;
				}
				cout << "\nIngrese el nickname del usuario del que desee eliminar un comentario: " << endl;
				string usuarioComentario;
				cin >> usuarioComentario;
				if (nombresUsuarios.find(usuarioComentario) != nombresUsuarios.end()){
					cout << "\nLos comentarios del usuario elegido son: "<< endl;
					set<DTComentario> ComentariosABorrar = CUsuario->obtenerListaComentarios(usuarioComentario);
					if (!ComentariosABorrar.empty()){
						for(set<DTComentario>::iterator it = ComentariosABorrar.begin(); it != ComentariosABorrar.end(); ++it){
							cout << (*it).getID() << ". " << (*it).getTexto() << endl;
						}
						int idComentarioABorrar;
						cout << "\nIngrese el id del comentario que desee eliminar: " << endl;
						cin >> idComentarioABorrar;
						bool idComentarioABorrarEncontrado = false;
						for(set<DTComentario>::iterator it = ComentariosABorrar.begin(); it != ComentariosABorrar.end() && !idComentarioABorrarEncontrado; it++){
							idComentarioABorrarEncontrado = ((*it).getID() == idComentarioABorrar);
						}
						if(idComentarioABorrarEncontrado){
							CUsuario->eliminarComentario(idComentarioABorrar);
						}else{
							cout << "\nEl id ingresado no es válido."<< endl;
						}						
					}else{
						cout << "\nEl usuario seleccionado no tiene comentarios para eliminar."<<endl;
					}

				}else{
					cout << "\nNo existe en el sistema un usuario con el nickname ingresado."<< endl; 
				}
				cin.ignore();
				break;
			}
			case 10:{//Enviar Producto
				cout << "\nLos nicknames de los vendedores ingresados en el sistema son:\n"<<endl;
				set<string> nombresVendedores = CCompra->obtenerVendedores();
				for (set<string> :: iterator it = nombresVendedores.begin(); it != nombresVendedores.end(); ++it){
					cout <<  (*it)<<endl;
				}
				cout << "\nIngrese el nickname del vendedor deseado: "<<endl;
				string nickVendedor;
				cin >> nickVendedor;
				if (nombresVendedores.find(nickVendedor) != nombresVendedores.end()){
						set<DTProducto> productosPendientes = CCompra->obtenerListaProdPendientes(nickVendedor);
					if (!productosPendientes.empty()){
						cout << "\nLos productos con compras pendientes de envio son:\n"<< endl;
						for (set<DTProducto>:: iterator it = productosPendientes.begin(); it != productosPendientes.end(); ++it){
							cout << (*it).toString();
							cout <<endl << endl;
						}
						cout << "Ingrese el código del producto que desee enviar en alguna compra pendiente: "<<endl;
						int productoPendiente;
						cin >> productoPendiente;
						bool productoPendienteEncontrado = false;
						for (set<DTProducto>::iterator it = productosPendientes.begin(); it != productosPendientes.end() && !productoPendienteEncontrado; ++it){
							productoPendienteEncontrado = ((*it).getCodigo() == to_string(productoPendiente));
						}
						if (productoPendienteEncontrado){
							vector<ParClienteCompra> comprasPendientes = CCompra->ObtenerComprasPendientes(productoPendiente);
							cout << "\nLas compras pendientes de envio son las siguientes:\n"<< endl;
							for(int it = 0; it < comprasPendientes.size();it++){
								cout << comprasPendientes[it].getId() << ": " << endl << "Nombre cliente: " << comprasPendientes[it].getNickname()<< endl << "Fecha de compra: " << comprasPendientes[it].getFechaC().toString() << endl << endl;
							}
							cout << "Ingrese el número de la compra que desea marcar el producto como enviado: "<< endl;
							int idCompraProdEniado;
							cin >> idCompraProdEniado;
							bool codigoCompraProdEnviadoEncontrado = false;
							for (int it = 0; it < comprasPendientes.size() && !codigoCompraProdEnviadoEncontrado; it++){
								codigoCompraProdEnviadoEncontrado = (idCompraProdEniado == comprasPendientes[it].getId());
							}
							if (codigoCompraProdEnviadoEncontrado){
								CCompra->CompraProdEnviada(idCompraProdEniado);
							}else{
								cout << "\nEl número ingresado no es válido"<<endl;
							}
						}else{
							cout <<"\nEl código ingresado no es válido"<<endl;
						}
					}else{
						cout << "\nEl vendedor elegido no tiene compras con productos pendientes de envio" << endl;
					}
				}else{
					cout << "\nNo existe en el sistema un vendedor con el nickname elegido" << endl;
				}
				cin.ignore();
				break;
			}
			case 11:{// Expediente de Usuario
				set<string> lusuarios = CUsuario->iniciarExpediente();
				if (!lusuarios.empty()){
					cout << "\nLos nicknames de los usuarios ingresados en el sistema son: "<<endl;
					set<string>::iterator ilu;
					for(ilu = lusuarios.begin(); ilu != lusuarios.end(); ++ilu){
						cout << (*ilu) << endl;
					}
					cout << "\nIngrese el nickname del usuario elegido:" << endl;
					string nick;
					getline(cin, nick);
					if (CUsuario->existeUsuario(nick)){
						DTExpU* exp = CUsuario->obtenerExpediente(nick);
						cout << exp->toString();
						cout << endl;
					}else{
						cout << "\nEl usuario ingresado no existe en el sistema"<< endl;
					}
				}else{
					cout<< "\nNo existen usuarios en el sistema" <<endl;
				}
				break;
			}
			case 12:{// Suscribirse a notificaciones
				cout << "\nLos nicknames de clientes del sistema son:"<< endl << endl;
				set<string> clientes = CUsuario->obtenerListaClientes();
				for (set<string>::iterator it = clientes.begin(); it != clientes.end(); ++it){
					cout << (*it)<< endl;
				}
				cout << "\nIngresar Nickname del cliente que se desea suscribir:" << endl;
				string nick, nickv;
				getline(cin, nick);
				if(clientes.find(nick) != clientes.end()){
					set<DTVendedor> vdisponibles = CUsuario->solicitarSuscribirse(nick);
					set<DTVendedor>::iterator ivd;
					if (!vdisponibles.empty()){
						cout << "\nLos vendedores a los cuales puede suscribirse son:" << endl;
						for(ivd = vdisponibles.begin(); ivd != vdisponibles.end(); ++ivd){
							cout << (*ivd).toString();
							cout << endl;
						}
						bool seguir = true;
						string s;
						while(seguir){
							cout << "\nIngrese el nickname del vendedor elegido:" << endl;
							getline(cin, nickv);
							bool nosuscrito = false;
							for (set<DTVendedor>::iterator it = vdisponibles.begin(); it != vdisponibles.end() && !nosuscrito; ++it){
								nosuscrito = (*it).getNickname() == nickv;
							}
							if(nosuscrito){
								if(!CUsuario->seleccionarVendedor(nickv)){
									cout << "\nEl vendedor ya fue seleccionado" << endl;
								};
							}else {
								cout << "\nEl nickname ingresado no corresponde a un vendedor válido" << endl;
							}
							cout << "\n¿Desea suscribirse a otro vendedor? (Si/No)" << endl;
							cin >> s;
							cin.ignore();
							if(s != "Si"){
								seguir = false;
							}
						}
						CUsuario->confirmarSuscripciones();
					}else{
						cout << "\nEl cliente no está suscrito a ningún vendedor" << endl;
					}
				}else{
					cout << "\nNo existe en el sistema un cliente con el nickname elegido" << endl;
				}
				break;
			}
			case 13:{// Consulta de notificaciones
				cout << "\nLos nicknames de los clientes en el sistema son: " <<endl;
				set<string> nombresUsuarios = CUsuario->obtenerListaClientes();
				for (set<string> :: iterator it = nombresUsuarios.begin(); it != nombresUsuarios.end();++it){
					cout << (*it) << endl;
				}
				cout << "\nIngrese el nickname del cliente a consultar notificaciones: " << endl;
				string nickAConsultar;
				cin >> nickAConsultar;
				if (nombresUsuarios.find(nickAConsultar) != nombresUsuarios.end()){
					cout << "\nLas notificaciones de " << nickAConsultar << " son: " << endl;
					set<DTNotificacion> notificaciones = CUsuario->obtenerNotificacionesCliente(nickAConsultar);
					for (set<DTNotificacion>:: iterator it = notificaciones.begin(); it != notificaciones.end(); ++it){
						cout << "Nombre del vendedor: " << (*it).getNicknameVendedor() << endl;
						cout << "Nombre de la promoción: " << (*it).getNombrePromocion() << endl;
						cout << "Productos: " << endl<< endl;
						set<DTProducto> prods = (*it).getProductos();
						for(set<DTProducto>:: iterator it2 = prods.begin(); it2 != prods.end(); ++it2){
							cout << "Nombre producto: " << (*it2).getNombre() << endl;
							cout << "Código: " << (*it2).getCodigo() << endl; 
							cout << "Categoría: " << toStringDTCategoria((*it2).getCategoria()) << endl;
							cout << "Descripcion: " << (*it2).getDescripcion() << endl;
							cout << "Precio: " << (*it2).getPrecio() << endl;
							cout << "Stock: " << (*it2).getStock() << "\n" << endl;
						}
					}
					CUsuario->eliminarNotificaciones();
				}else{
					cout << "\nNo existe en el sistema un cliente con nikname " << nickAConsultar << endl;
				}
			break;
			}
			case 14:{//Eliminar suscripciones
				cout << "\nLos nicknames de los clientes del sistema son: "<< endl;
				set <string> nomVendedores = CUsuario->obtenerListaClientes();
				for (set<string>:: iterator it = nomVendedores.begin(); it != nomVendedores.end(); ++it){
					cout << (*it) << endl;
				}
				cout <<"\nIngrese el nikname del cliente deseado: "<< endl;
				string nomCli;
				cin >> nomCli;
				if (nomVendedores.find(nomCli) != nomVendedores.end()){
					cout << "\nEl cliente se encuentra suscrito a los siguientes vendedores: " <<endl;
					set<DTVendedor*> vendedoresAsoc = CUsuario->vendedoresAsociados(nomCli);
					for (set<DTVendedor*> :: iterator it = vendedoresAsoc.begin(); it != vendedoresAsoc.end(); ++it){
						cout << (*it)->toString() << endl;
					}
					bool fin = false;
					while (!fin){
						cout << "\nIngrese el nickname del vendedor a desuscribir: "<< endl;
						string nombreVendedor;
						cin >> nombreVendedor;
						bool nombreVendedorEncontrado = false;
						for (set<DTVendedor*> :: iterator it = vendedoresAsoc.begin(); it != vendedoresAsoc.end() && !nombreVendedorEncontrado; ++it){
							nombreVendedorEncontrado = ((*it)->getNickname() == nombreVendedor);
						}
						if (nombreVendedorEncontrado){
							CUsuario->seleccionarVendedor(nombreVendedor);
							 
						}else{
							cout << "\nEl nickname ingresado no corresponde a un vendedor del que " << nomCli << " esté suscrito" << endl;
						}
						cout << "\nDesea seguir seleccionando vendedores? (Si/No)"<< endl;
						string res;
						cin >> res;
						if (res != "Si"){
							fin = true;
						}
					}
					CUsuario->confirmarDesuscripciones();
				}else{
					cout << "\nNo existe en el sistema un cliente con nickname " << nomCli << endl;
				}
			break;
			}
			case 15:{
				cout << "Ingrese la fecha actual:" << endl;
				cout << "Día:" << endl;
				cin >> dia;
				cout << "Mes:" << endl;
				cin >> mes;
				cout << "Año:" << endl;
				cin >> anio;
				fechaActual->setDia(dia);
				fechaActual->setMes(mes);
				fechaActual->setAnio(anio);
				break;
			}
			case 16:{
				CargarDatos();
				break;
			}
			default: cout << "\nEl número ingresado no corresponde a ningún caso de uso."<<endl;
		}
		cout << endl << "Si quiere realizar otro caso de uso ingrese 1 sino ingrese 0:" << endl;
		cin >> seguir;
	}







	


return 0;
}

