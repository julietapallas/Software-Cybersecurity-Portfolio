#ifndef _COMENTARIO_HH_
#define _COMENTARIO_HH_

#include "Producto.hh"
#include "Usuario.hh"
class Producto;
class Usuario;
class Comentario {
private:
    string Texto;
    DTFecha Fecha;
    Producto* ProductoComentado;
    set<Comentario*> Respuestas;
    Usuario* realizaCom;
    Comentario* respondeA;
    int ID;
public:
    //CREADOR, DESTRUCTOR, GETTERS Y SETTERS
    Comentario(string Texto,DTFecha Fecha,int id);
    
    ~Comentario();
    
    void setTexto(string Texto);
    
    void setFecha(DTFecha Fecha);
    
    void setProductoComentado(Producto* ProductoComentado);
    
    void setRespuesta(Comentario* Respuesta);

    void setRespuestas(set<Comentario*> respuestas);

    void setID(int id);

    void setRealizaCom(Usuario* u);

    void setRespondeA(Comentario* c);

    int getID();
    
    string getTexto();
    
    DTFecha getFecha();
    
    Producto* getProductoComentado();
    
    set<Comentario*> getRespuestas();

    Usuario* getRealizaCom();

    Comentario* getRespondeA();

    void eliminarRespuestas();
    
    void eliminarRespuesta(Comentario* c);

    //INTERACCIONES
    DTComentario getDTComentario();
};

#endif