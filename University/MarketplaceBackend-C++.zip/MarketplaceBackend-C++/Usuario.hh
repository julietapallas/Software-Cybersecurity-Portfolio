#ifndef _USUARIO_HH_
#define _USUARIO_HH_
#include "DT.hh"
#include "Comentario.hh"

#include <set>
#include <string>
#include <map>
class Comentario;
class Compra;
class Usuario {
private:
    string nickname, contrasenia;
    DTFecha fechaNacim;
    set<Comentario*> ComentariosRealizados;
    map<string,Usuario*> SuscriptosOSuscripciones;
protected:
    set<Compra*> ComprasRealizadas;
public:
    //CREADOR, DESTRUCTOR, GETTERS Y SETTERS
    Usuario(string nick, string cont, DTFecha FN);
    virtual ~Usuario() = 0;
    string getNickname();
    string getContrasenia();
    DTFecha getFecha();
    map<string,Usuario*> getSuscriptosOSuscripciones();
    void setSuscriptosOSuscripciones(map<string,Usuario*> sos);
    void setSOS(string nombre,Usuario* usuario); 
    void setNickname(string nick);
    void setContrasenia(string cont);
    void setFecha(DTFecha fecha);
    void setComentario(Comentario* com);
    void setComentariosRealizados(set<Comentario*> cr);
    set<Comentario*> getComentariosRealizados();
    //INTERACCIONES
    bool UsuarioAsociado(Usuario* User);
    
    void desasociar(Usuario* aDesasociar);
    void eliminarComentario(int aEliminar);
    void eliminarComentario(Comentario* c);
    set<DTComentario> obtenerComentarios();
    void setCompra(Compra* CompraRealizada);
    virtual DTExpU* obtenerExpediente()= 0;

};
#endif

