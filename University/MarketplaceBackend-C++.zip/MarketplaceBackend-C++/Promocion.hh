#ifndef __PROMOCION__HH
#define __PROMOCION__HH
#include "DT.hh"
#include "PromocionProducto.hh"
#include <set>
#include <string>
using namespace std;
class PromocionProducto;
class Promocion {
    private:
        string Nombre;
        string Descripcion;
        float Descuento;
        DTFecha FechaVenc;
        set<PromocionProducto*> ColeccionPromProds;

    public:
        Promocion(string N, string Descr, float Descu, DTFecha FV,set<PromocionProducto*> colecc);
        ~Promocion();
        void setNombre(string N);
        void setDescripcion(string Descr);
        void setDescuento(float Descu);
        void setFechaVenc(DTFecha FV);
        void Asociar(PromocionProducto* PromProd);

        string getNombre();
        string getDescripcion();
        float getDescuento();
        DTFecha getFechaVenc();
        set<PromocionProducto*> getColeccionPromProds();

        DTPromocion getDTPromocion();
        DTProm getDTProm();
        bool hechaPorVend(string nickname);

};
#endif
