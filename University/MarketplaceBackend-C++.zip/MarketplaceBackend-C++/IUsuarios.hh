#ifndef __IUSUARIOS__HH
#define __IUSUARIOS__HH
#include "DT.hh"


class IUsuarios {
public:
	virtual string ingresarUsuario(DTUsuario* Usuario) = 0;
	
	virtual set<string> obtenerListaClientes() = 0;
	
	virtual set<DTVendedor> solicitarSuscribirse (string nickname) = 0;
	
	virtual bool seleccionarVendedor(string vendedor) = 0;
	
	virtual void confirmarSuscripciones() = 0;
	
	virtual set<string> obtenerVendedores() = 0;
	
	virtual set<string> obtenerListaNicknames() = 0;
	
	virtual set<DTComentario> obtenerListaComentarios(string usuario) = 0;

	virtual void eliminarComentario(int comentario) = 0;
	
	virtual void eliminarNotificaciones() = 0;
	
	virtual set<DTNotificacion> obtenerNotificacionesCliente(string nicnkame) = 0;
	
	virtual set<DTVendedor*> vendedoresAsociados(string nick) = 0;

	virtual set<string> obtenerUsuarios()=0;

	virtual set<DTProductoCN> obtenerProductos(string usuario)=0;

	virtual void selecProd(DTProductoCN producto)=0;

	virtual  set<DTComentario> obtenerListaComentarios()=0;

	virtual void AgregarComentario(string texto) = 0;

	virtual void AgregarRespuesta(string texto, int idcomentario)=0;

	virtual set<DTUsuario*> consultarInfoUsuario() = 0;
	
	virtual  bool existeUsuario(string nick) = 0; 

	virtual set<string> iniciarExpediente()=0;
        
    virtual DTExpU* obtenerExpediente(string NUsuario) = 0;
        
    virtual void confirmarDesuscripciones()=0;


	virtual ~IUsuarios(){};
};

#endif
