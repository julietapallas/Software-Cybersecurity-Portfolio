#ifndef __CONTROLADORCOMPRAS__HH
#define __CONTROLADORCOMPRAS__HH

#include <vector>
#include "ICompras.hh"
#include "Compra.hh"

class ControladorCompras : public ICompras{
    private:
        set<ParCodCant> C;
        static ControladorCompras * instCCompra;
        ControladorCompras();
        vector<Compra*> compra;
        int Contador;
        int Codigo;
        Usuario* UsuarioRecordado;
    public:
        static  ControladorCompras * getInstancia();
        void setC(set<ParCodCant> par);
        void setCompra(Compra* C);
        void setCodigo(int cod);
        void setUsuarioRecordado(Usuario* u);
        set<ParCodCant> getC();
        vector<Compra*> getCompra();
        int getContador();
        int getCodigo();
        Usuario* getUsuarioRecordado();


        set<string> obtenerListaClientes();
        set<DTProducto> obtenerListaProdPendientes(string nick);
        set<DTProducto> elegirCliente(string nick);
        bool ingresarProducto(int cod, int cant);
        vector<ParClienteCompra> ObtenerComprasPendientes(int codigo);
        void CompraProdEnviada(int id);
        ParCompraProductos obtenerDatosCompra();
        set<ParCompraProductos> ComprasDeVend(string nickname);
        set<string> obtenerVendedores();
};
#endif
