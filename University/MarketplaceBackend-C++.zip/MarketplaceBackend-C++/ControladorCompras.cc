#ifndef __CONTROLADORCOMPRAS__CC
#define __CONTROLADORCOMPRAS__CC

#include "ControladorCompras.hh"
#include "ControladorProductos.hh"
#include "ControladorUsuarios.hh"
#include "Usuario.hh"
#include "Cliente.hh"
#include"Vendedor.hh"



ControladorCompras* ControladorCompras::instCCompra = NULL;
ControladorCompras::ControladorCompras() {
    Contador = 0;
}
ControladorCompras* ControladorCompras::getInstancia(){
    if(instCCompra == NULL)
 instCCompra = new ControladorCompras();
    return instCCompra;
}

  void ControladorCompras::setC(set<ParCodCant> par){
    C = par;
}
  void ControladorCompras::setCompra(Compra* C){
    compra.push_back(C);
}

  void ControladorCompras::setCodigo(int cod){
 Codigo = cod;
}

  void ControladorCompras::setUsuarioRecordado(Usuario *u){
    UsuarioRecordado = u;
}

int ControladorCompras::getContador(){
    return Contador;
}

Usuario *ControladorCompras::getUsuarioRecordado(){
    return UsuarioRecordado;
}

int ControladorCompras::getCodigo(){
    return Codigo;
}
set<ParCodCant> ControladorCompras::getC(){
    return C;
}
vector<Compra*> ControladorCompras::getCompra(){
    return compra;
}

set<string> ControladorCompras::obtenerListaClientes(){
    ControladorUsuarios* CUsuarios = ControladorUsuarios::getInstancia();
    return CUsuarios->obtenerListaClientes();
}
set<DTProducto> ControladorCompras::elegirCliente(string nick){
    ControladorUsuarios* CUsuarios = ControladorUsuarios::getInstancia();
 ControladorProductos* CProductos = ControladorProductos::getInstancia();
    setUsuarioRecordado(CUsuarios->elegirCliente(nick));
    return CProductos->elegirCliente(nick);
}
  bool ControladorCompras::ingresarProducto(int cod, int cant){
    bool exito = false;
 ControladorProductos* CProductos = ControladorProductos::getInstancia();
    int stock = CProductos->ingresarProducto( cod, cant);
    if(cant <= stock){
        exito = true;
        ParCodCant par = ParCodCant(cod, cant);
        C.insert(par);
    }
    return exito;
}
ParCompraProductos ControladorCompras::obtenerDatosCompra(){
    set<ParCodCant> pares = getC();

    ControladorProductos* CProductos = ControladorProductos::getInstancia();
    float MontoFinal = CProductos->ObtenerPrecio(pares);
    set<CompraProducto*> listaCProd = CProductos->ObtenerProductos(pares);
    
    FechaAct* fechaActual = FechaAct::getInstancia();
    Compra* c = new Compra(fechaActual->getDTFecha(), MontoFinal);
    set<DTProducto> prods;
    if (MontoFinal != 0){
        UsuarioRecordado->setCompra(c);
        c->setUsuario(getUsuarioRecordado());
        set<CompraProducto*>::iterator it;
        for(it = listaCProd.begin(); it != listaCProd.end(); ++it){
            c->setCompraProd((*it));
            int cant = (*it)->getCantProd();
            Producto* p = (*it)->getProducto();
            int stock = p->getStock();
            p->setStock(stock - cant);
            prods.insert(p->getDTProducto());//con el stock ya cambiado?
            (*it)->setCompra(c);
        }
        c->setId(getContador());
        compra.push_back(c);
        Contador++;
        setUsuarioRecordado(nullptr);
        C.clear();
    }
    DTCompra dtc = DTCompra(c->getMontofinal(),c->getFecha());
    return  ParCompraProductos(dtc ,prods);
}

set<DTProducto> ControladorCompras::obtenerListaProdPendientes(string nick){
    ControladorProductos* CProd = ControladorProductos::getInstancia();
    return CProd->obtenerListaProdsPendientes(nick);
}


vector<ParClienteCompra> ControladorCompras::ObtenerComprasPendientes(int codigo){
    vector<ParClienteCompra> ret;
    setCodigo(codigo);
    for (int i = 0; i < compra.size();i++){
        if (compra[i]->CorrespondeCompra(codigo)){
            ParClienteCompra PCliCom = compra[i]->getParClienteCompra();
            ret.push_back(PCliCom);
        }
    }
    return ret;
}

void ControladorCompras::CompraProdEnviada(int id){
    int cod = Codigo;
    for (int i = 0; i < compra.size(); i++){
        if (compra[i]->getId() == id){
            compra[i]->marcarProdEnviado(cod);
        }
    }
}

set<ParCompraProductos> ControladorCompras::ComprasDeVend(string nickname){
    set<ParCompraProductos> ComVend = {};
    for(int i=0;i < compra.size();i++){
        Usuario* posibleVend = compra[i]->getUsuario();
        if(posibleVend->getNickname() == nickname)
            ComVend.insert(compra[i]->obtenerParCompraProductos());
    }
    return ComVend;
}

set<string> ControladorCompras:: obtenerVendedores(){
    ControladorUsuarios* Cusuarios = ControladorUsuarios::getInstancia();
    return Cusuarios->obtenerVendedores(); 
}
#endif
