#ifndef __FABRICA__HH__
#define __FABRICA__HH__
#include "ControladorPromociones.hh"
#include "ControladorCompras.hh"
#include "ControladorUsuarios.hh"
#include "ControladorProductos.hh"
class Fabrica {
public:
   static IPromociones* getContPromocion();
   static ICompras* getContCompras();
   static IUsuarios* getContUsuarios();
   static IProductos* getContProductos();
};
#endif