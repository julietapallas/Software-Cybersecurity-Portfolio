#include "ControladorPromociones.hh"
#include "ControladorUsuarios.hh"
#include "ControladorProductos.hh"


ControladorPromociones::ControladorPromociones(){}


void ControladorPromociones :: setListaProds(set<ParCodCant> PPC){
    ListaProds = PPC;
}

void ControladorPromociones :: setNickname(string N){
    nickname = N;
}

void ControladorPromociones :: setdataPromo(DTPromocion dtPromo){
    dataPromo = dtPromo;
}

set<ParCodCant> ControladorPromociones :: getListaProds(){
    return ListaProds;
}

string ControladorPromociones :: getNickname(){
    return nickname;
}

DTPromocion ControladorPromociones :: getdataPromo(){
    return dataPromo;
}


ControladorPromociones* ControladorPromociones :: InstControladorPromos = nullptr;
ControladorPromociones* ControladorPromociones:: getInstancia(){
    if (InstControladorPromos == nullptr){
        InstControladorPromos = new ControladorPromociones();
    }
    return InstControladorPromos;
}

void ControladorPromociones :: ingresarPromo(DTPromocion dtPromo){
    setdataPromo(dtPromo);
};



set<string> ControladorPromociones :: obtenerVendedores(){
    
    ControladorUsuarios * Cusuarios = ControladorUsuarios::getInstancia();
    return Cusuarios->obtenerVendedores();
};

set<DTProductoCN> ControladorPromociones :: obtenerProductosVend(string nickname){
    setNickname(nickname);
    ControladorProductos* CProd = ControladorProductos::getInstancia();
    return CProd->ObtenerProductosVend(nickname);
};
bool ControladorPromociones:: selecProd(ParCodCant producto){
    ControladorProductos* Cprods = ControladorProductos::getInstancia();
    int cod = producto.getCodigo();
    bool perteneceVendedor = Cprods->esVendedor(nickname,cod);
    bool estaEnPromoVigente = Cprods->estaEnPromoVigente(producto.getCodigo());
    bool yaElegido = ListaProds.find(producto) != ListaProds.end();
    if (perteneceVendedor && !yaElegido && !estaEnPromoVigente){
        ListaProds.insert(producto);
    }
    return (perteneceVendedor && !yaElegido && !estaEnPromoVigente);
};

bool ControladorPromociones :: altaPromocion(){
    bool creada = false;
    if (!ListaProds.empty()){
        DTPromocion dtPromo = getdataPromo();
        Promocion* Promo = new Promocion(dtPromo.getNombre(),dtPromo.getDescripcion(),dtPromo.getDescuento(),dtPromo.getFechaVenc(),{});
        ColeccionPromos.insert(Promo);
        ControladorProductos* CProd = ControladorProductos::getInstancia();
        set<DTProducto> ListaProdsAsociados = CProd->AsociarProductos(ListaProds,Promo);

        ControladorUsuarios* Cusuarios = ControladorUsuarios ::getInstancia();
        Cusuarios->NotificarClientes(nickname,dtPromo.getNombre(),ListaProdsAsociados);
        ListaProds.clear();
        creada = true;
    }
    return creada;
}

set<DTPromocion> ControladorPromociones::IniciarConsulta(){
    set<DTPromocion> promVigentes = {};
    set<Promocion*>::iterator it;
    FechaAct* FechaActual = FechaAct::getInstancia();
    for(it=ColeccionPromos.begin();it!=ColeccionPromos.end();++it){
        Promocion* prom = *it;
        if(FechaActual->getDTFecha() < prom->getFechaVenc())
            promVigentes.insert(prom->getDTPromocion());
    }
    return promVigentes;
};

DTProm ControladorPromociones::DatosPromocion(DTPromocion PromElegida){
    set<Promocion*>::iterator it = ColeccionPromos.begin();
    Promocion* prom;
    while(it != ColeccionPromos.end()){
        prom = *it;
        if(prom->getDTPromocion() == PromElegida)
            it = ColeccionPromos.end();
        else
            it++;
    }
    return prom->getDTProm();
}

set<DTPromocion> ControladorPromociones::promocionesDelVendedor(string nickname){
    set<DTPromocion> PromsDeVend = {};
    set<Promocion*>::iterator it = ColeccionPromos.begin();
    for(it;it != ColeccionPromos.end();it++){
        Promocion* promo = *it;
        FechaAct* FA = FechaAct::getInstancia();
        if(FA->getDTFecha()<promo->getFechaVenc() & promo->hechaPorVend(nickname))
            PromsDeVend.insert(promo->getDTPromocion());
    }
    return PromsDeVend;
}

set<Promocion*> ControladorPromociones:: getPromociones(){
	return ColeccionPromos;
	}
