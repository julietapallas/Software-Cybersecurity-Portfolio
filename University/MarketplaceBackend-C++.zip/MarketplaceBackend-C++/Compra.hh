#ifndef __COMPRA__HH
#define __COMPRA__HH

#include "CompraProducto.hh"
#include "Usuario.hh"

#include "DT.hh"
#include <vector>
class Usuario;
class Compra{
    private:
        DTFecha Fecha;
        float Montofinal;
        vector<CompraProducto*> CompraProd;
        Usuario * usuario;
        int id;
    public:
        Compra(DTFecha F, float Mf);
        ~Compra();

        void setFecha(DTFecha F);
        void setMontofinal(float Mf);
        void setCompraProd(CompraProducto* CP);
        void setUsuario(Usuario* u);
        void setId(int i);
        DTFecha getFecha();
        float getMontofinal();
        vector<CompraProducto*> getCompraProd();
        Usuario* getUsuario();
        int getId();
        bool CorrespondeCompra(int cod);        
        void setCompra(float Mf, DTFecha F);//se usa?
        ParClienteCompra getParClienteCompra();
        void marcarProdEnviado(int codigo);
        ParCompraProductos obtenerParCompraProductos();
};

#endif
