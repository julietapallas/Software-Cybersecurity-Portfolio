#include "PromocionProducto.hh"
#include "Vendedor.hh"
#include "Cliente.hh"
#include "Producto.hh"
PromocionProducto::PromocionProducto(int CM, Promocion* promo, Producto* prod){
    CantMin=CM;
    promocion = promo;
    producto = prod;

}

PromocionProducto :: ~PromocionProducto(){

}

int PromocionProducto::getCantMin(){
return CantMin;
}


DTFecha PromocionProducto:: getFecha(){

return promocion->getFechaVenc();


}

Promocion* PromocionProducto:: getPromocion(){
return promocion;
}

Producto* PromocionProducto:: getProducto(){
return producto;
}

 void PromocionProducto::setCantMin(int CM){
  CantMin= CM;
 }


  void PromocionProducto:: setProducto(Producto * prod){
    producto=prod;

  }

  void PromocionProducto::setPromocion(Promocion * prom){
    promocion=prom;
  }


float PromocionProducto::ObtenerDescuento(){
  return promocion->getDescuento();
}

bool PromocionProducto::correspondeCantMin(int cant){
  if(CantMin > cant){
    return false;
  }else return true; 

}

DTVendedor PromocionProducto::getDTVendedor(){
    Vendedor *vend = dynamic_cast<Vendedor*>(producto->getVendedor());
    return vend->getDTVendedor();
};

DTProd PromocionProducto::getDTProd(){
    DTProd prod(producto->getDTProducto(),CantMin);
    return prod;
};

bool PromocionProducto::hechaPorVend(string nickname){
    Usuario* posibleVend = producto->getVendedor();
    return nickname == posibleVend->getNickname();
}
