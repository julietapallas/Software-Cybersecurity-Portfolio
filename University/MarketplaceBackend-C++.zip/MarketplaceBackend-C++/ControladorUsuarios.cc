#include "ControladorUsuarios.hh"
#include "ControladorProductos.hh"
#include "Comentario.hh"
#include "Vendedor.hh"
#include "Cliente.hh"

   ControladorUsuarios::ControladorUsuarios(){
      ID=0;
   };
  
   void ControladorUsuarios::setID(int id){
    ID=id;
}

int ControladorUsuarios::getID(){
    return ID;
} 

   void ControladorUsuarios:: setproductoAcomentar(DTProductoCN producto){
      productoAcomentar=producto;
   }
   DTProductoCN ControladorUsuarios:: getproductoAcomentar(){
      return productoAcomentar;
   }
   
   void ControladorUsuarios::setUsuarioRecordado(Usuario* aRecordar){
      UsuarioRecordado = aRecordar;
   };
   
   Usuario* ControladorUsuarios::getUsuarioRecordado(){
      return UsuarioRecordado;
   };

   Usuario* ControladorUsuarios::getUsuario(string nick){
      map<string, Usuario*>:: iterator it = ColeccionUsuarios.find(nick);
      return it->second;
   }
   
   ControladorUsuarios* ControladorUsuarios:: Instancia = nullptr;
   ControladorUsuarios* ControladorUsuarios::getInstancia(){
      if (Instancia == nullptr){
         Instancia = new ControladorUsuarios();
      }
      return Instancia;
   };

   string ControladorUsuarios::ingresarUsuario(DTUsuario* dataUsuario){
      map<string,Usuario*>::iterator it = ColeccionUsuarios.find(dataUsuario->getNickname());
      string res = "Error";
      if (it == ColeccionUsuarios.end()){
         if (DTCliente* cliente = dynamic_cast<DTCliente*>(dataUsuario)){
            Usuario* Ucliente = new Cliente(cliente->getNickname(),cliente->getContrasenia(),cliente->getCiudad(),cliente->getFechaNac(),cliente->getDireccion(),cliente->getNotificaciones());
            ColeccionUsuarios[cliente->getNickname()] = Ucliente;
         }else{
            DTVendedor* vendedor = dynamic_cast<DTVendedor*>(dataUsuario);
            Usuario* Uvendedor = new Vendedor(vendedor->getNickname(),vendedor->getContrasenia(),vendedor->getCodigoRUT(),vendedor->getFechaNac());
            ColeccionUsuarios[vendedor->getNickname()] = Uvendedor;
         }
         res = "Listo";
      }
      return res; 
      
   };

    set <DTUsuario*> ControladorUsuarios :: consultarInfoUsuario () {
      
      set <DTUsuario*> infoUsuarios = {};
      map<string,Usuario*> :: iterator it;
         for(it = ColeccionUsuarios.begin(); it != ColeccionUsuarios.end(); ++it) {
            if (Cliente* cliente = dynamic_cast<Cliente*>(it->second)) {
               DTCliente* datosCliente = new DTCliente(cliente->getNickname(),cliente->getContrasenia(),cliente->getFecha(),cliente->getDireccion(),cliente->getCiudad(),cliente->getNotificaciones());
               infoUsuarios.insert(datosCliente);
            }
            else if(Vendedor* vendedor = dynamic_cast<Vendedor*>(it->second)){ 
               DTVendedor* datosVendedor = new DTVendedor(vendedor->getNickname(),vendedor->getContrasenia(),vendedor->getFecha(),vendedor->getCodigoRUT());
               infoUsuarios.insert(datosVendedor);
            }
         }
      return infoUsuarios;
   };

    
   set<string> ControladorUsuarios::obtenerListaClientes(){
      
      map<string,Usuario*> :: iterator it;
      set<string> clientes = {};
      for(it = ColeccionUsuarios.begin(); it != ColeccionUsuarios.end(); ++it) {
         if (Cliente* cliente = dynamic_cast<Cliente*>(it->second)){
            clientes.insert(cliente->getNickname());
         }
      }
      return clientes;
   
   };


   bool ControladorUsuarios::existeUsuario(string nick){
       return ColeccionUsuarios.find(nick) != ColeccionUsuarios.end();
   };

    
   Usuario* ControladorUsuarios::elegirCliente(string nickname){
      map<string,Usuario*> ::iterator it = ColeccionUsuarios.begin();
      while(it != ColeccionUsuarios.end() && it->second->getNickname() != nickname){
         it++;
      }
      if(it != ColeccionUsuarios.end()){
         return it->second;
      }
      else return nullptr;
   }
 
 
   set<DTVendedor> ControladorUsuarios::solicitarSuscribirse (string nickname){
    Usuario* usrecordado=getUsuario(nickname);
    setUsuarioRecordado(usrecordado);
    map<string,Usuario*> ColeccionSusc =usrecordado->getSuscriptosOSuscripciones();
      map<string,Usuario*> ::iterator it;
      set<DTVendedor> ColeccVend = {};
      for(it = ColeccionUsuarios.begin(); it != ColeccionUsuarios.end(); ++it){
         if (Vendedor* vendedor = dynamic_cast<Vendedor*>(it->second)){
            bool asociado= usrecordado->UsuarioAsociado(vendedor);
            if (asociado==false){
               DTVendedor vend= vendedor->getDTVendedor();
               ColeccVend.insert(vend);
            }


         }
      }
      return ColeccVend;
      
   };
    
   bool ControladorUsuarios::seleccionarVendedor(string vendedor){
   	Usuario * usuario=ColeccionUsuarios[vendedor];
   	bool nopertenece = (ColeccVendedores.find(usuario) == ColeccVendedores.end());
   	if (nopertenece){
      		ColeccVendedores.insert(usuario);
      	}
      	return nopertenece;
   };

     
      

    
   void ControladorUsuarios::confirmarSuscripciones(){
      set<Usuario*> ::iterator it=ColeccVendedores.begin();
      for(it; it != ColeccVendedores.end(); ++it){  
         Usuario * usuario=*it;
         UsuarioRecordado->setSOS(usuario->getNickname(),usuario);
         (*it)->setSOS(UsuarioRecordado->getNickname(), UsuarioRecordado);
         }
         UsuarioRecordado=nullptr;
         ColeccVendedores.clear();    
   };	
   set<string> ControladorUsuarios::obtenerVendedores(){
      map<string,Usuario*> ::iterator it;
      set<string> ColeccNombres = {};
      for(it = ColeccionUsuarios.begin(); it != ColeccionUsuarios.end(); ++it){
         if (Vendedor* vendedor = dynamic_cast<Vendedor*>(it->second)){
            ColeccNombres.insert(vendedor->getNickname());
         }
      }
      return ColeccNombres;
   };	
 
   set<string> ControladorUsuarios::obtenerListaNicknames(){
      set<string> nicknames;
      for(map<string,Usuario*>::iterator it = ColeccionUsuarios.begin(); it != ColeccionUsuarios.end(); ++it){
         nicknames.insert(it->first);
      }
      return nicknames;
   };	

   set<DTComentario> ControladorUsuarios::obtenerListaComentarios(string usuario){
      Usuario * u = ColeccionUsuarios[usuario];
      setUsuarioRecordado(u);
      return u->obtenerComentarios();
   };
    
   void ControladorUsuarios::eliminarComentario(int comentario) {
      UsuarioRecordado->eliminarComentario(comentario);
   };

   void ControladorUsuarios::eliminarNotificaciones(){
      if (Cliente* c = dynamic_cast<Cliente*>(UsuarioRecordado)){
         c->eliminarNotificaciones();
      }
   };
        
   set<DTNotificacion> ControladorUsuarios::obtenerNotificacionesCliente(string nickname){
      set<DTNotificacion> ret = {};
      map<string,Usuario*> :: iterator itu = ColeccionUsuarios.find(nickname);
      if (itu != ColeccionUsuarios.end()){
         Usuario* u = itu->second;
         if(Cliente* c = dynamic_cast<Cliente*>(u)){
            ret = c->getNotificaciones();
            setUsuarioRecordado(u);
         }
      }
      return ret;
   };
       
   set<DTVendedor*> ControladorUsuarios::vendedoresAsociados(string nick){
      map<string,Usuario*>::iterator it = ColeccionUsuarios.find(nick);
       UsuarioRecordado = it->second;
       Cliente* c = dynamic_cast<Cliente*>(it->second);
       return c->vendedoresAsociados();

   };

   ControladorUsuarios::~ControladorUsuarios(){};

   void ControladorUsuarios::NotificarClientes(string nick,string nombrePromo,set<DTProducto> listaProds){
      map<string,Usuario*>:: iterator u = ColeccionUsuarios.find(nick);
      map<string, Usuario*>:: iterator it;
      map<string, Usuario*> coleccionSuscriptos = u->second->getSuscriptosOSuscripciones();
      for (it = coleccionSuscriptos.begin();it !=coleccionSuscriptos.end(); ++it){
         Cliente* c = dynamic_cast<Cliente*>(it->second);
         c->notificar(nick,nombrePromo,listaProds);
         
      }
      
   };


       set<string> ControladorUsuarios::obtenerUsuarios(){
      map<string,Usuario*> ::iterator it;
      set<string> ColeccNombres = {};
      for(it = ColeccionUsuarios.begin(); it != ColeccionUsuarios.end(); ++it){
         if (Vendedor* vendedor = dynamic_cast<Vendedor*>(it->second)){
            ColeccNombres.insert(vendedor->getNickname());
         }
         else if(Cliente* cliente =dynamic_cast<Cliente*>(it->second)){
          ColeccNombres.insert(cliente->getNickname());
      }
      }
      return ColeccNombres; 
   };

  set<DTProductoCN> ControladorUsuarios :: obtenerProductos(string usuario){
    Usuario* usrecordado=getUsuario(usuario);
    setUsuarioRecordado(usrecordado);
    ControladorProductos* CProd = ControladorProductos::getInstancia();
    return CProd->ObtenerListaProductos();
};

 void ControladorUsuarios:: selecProd(DTProductoCN producto){
   productoAcomentar=producto;
   
};

void ControladorUsuarios:: AgregarComentario(string texto){
   FechaAct * FechaAct= FechaAct::getInstancia();
   DTFecha fecha= DTFecha(FechaAct->getDia(), FechaAct->getMes(),FechaAct->getAnio());
   ID++;
   Comentario *nuevocoment= new Comentario(texto,fecha,ID);

   ControladorProductos*CProd=ControladorProductos::getInstancia();
   Producto * producto= CProd->obtenerProducto(productoAcomentar);
   
   nuevocoment->setProductoComentado(producto);
   producto->setComentario(nuevocoment);
   UsuarioRecordado->setComentario(nuevocoment);
   nuevocoment->setRealizaCom(UsuarioRecordado);
   nuevocoment->setRespondeA(NULL);
}

  set<DTComentario> ControladorUsuarios::obtenerListaComentarios(){
   ControladorProductos*CProd=ControladorProductos::getInstancia();
   Producto * producto= CProd->obtenerProducto(productoAcomentar);
   return producto->obtenerComentarios();
   }
   
   void ControladorUsuarios:: AgregarRespuesta(string texto, int idcomentario){
   //creo comentario para agregar al set de respuestas
   FechaAct * FechaAct= FechaAct::getInstancia();
   DTFecha fecha= DTFecha(FechaAct->getDia(), FechaAct->getMes(),FechaAct->getAnio());
   ID++;
   Comentario *nuevocoment= new Comentario(texto,fecha,ID);

   //OBTENGO EL PUNTERO ACOMENTARIO AL QUE QUIERO RESPONDER
   bool encontrado = false;
   Comentario* coment = nullptr;
   for(map<string, Usuario*>::iterator it = ColeccionUsuarios.begin(); it != ColeccionUsuarios.end() && !encontrado; ++it){
      set<Comentario*> comentarios = it->second->getComentariosRealizados();
      for (set<Comentario*>::iterator it2 = comentarios.begin(); it2 != comentarios.end() && !encontrado; ++it2){
         if((*it2)->getID() == idcomentario){
            encontrado = true;
            coment = *it2;
         }
      }
   }
   if (encontrado){
      coment->setRespuesta(nuevocoment); 
    
      ControladorProductos*CProd=ControladorProductos::getInstancia();
      Producto * producto= CProd->obtenerProducto(productoAcomentar);
      nuevocoment->setProductoComentado(producto);
   
      producto->setComentario(nuevocoment);
      UsuarioRecordado->setComentario(nuevocoment);
      nuevocoment->setRealizaCom(UsuarioRecordado);
      nuevocoment->setRespondeA(coment);
   }
  
}

set<string> ControladorUsuarios::iniciarExpediente(){
       set<string> NombreUsuarios = {};
       map<string,Usuario*>::iterator it = ColeccionUsuarios.begin();
       for(it;it != ColeccionUsuarios.end();it++)
           NombreUsuarios.insert(it->first);
       return NombreUsuarios;
}

DTExpU* ControladorUsuarios::obtenerExpediente(string NUsuario){
       map<string,Usuario*>::iterator it = ColeccionUsuarios.begin();
       Usuario* res = ColeccionUsuarios[NUsuario];
       return res->obtenerExpediente();
}
    
   void ControladorUsuarios::confirmarDesuscripciones(){
      set<Usuario*>::iterator it = ColeccVendedores.begin();
       for(it;it != ColeccVendedores.end();it++){
           Usuario* vendedor = *it;
           UsuarioRecordado->desasociar(vendedor);
           vendedor->desasociar(UsuarioRecordado);
       }
       ColeccVendedores.clear();
       UsuarioRecordado = NULL;
   };
