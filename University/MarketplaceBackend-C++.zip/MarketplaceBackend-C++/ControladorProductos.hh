#ifndef __ControladorProductos__HH__
#define __ControladorProductos__HH__
#include "DT.hh"
#include "Producto.hh"
#include <map>
#include "IProductos.hh"
class Producto;

class ControladorProductos: public IProductos{
    private:
        ControladorProductos();
        static ControladorProductos * InstControladorProd;
        map<int,Producto*> ColeccionProds;
         int Contador;
    public: 
       static ControladorProductos * getInstancia();

       set<DTProducto> elegirCliente(string nick);
       set<DTProducto> AsociarProductos(set <ParCodCant> ListaProds,Promocion* p); 
       int ingresarProducto(int cod, int cant);
       float ObtenerPrecio(set <ParCodCant> cc); 
       set<DTProductoCN> ObtenerProductosVend(string nickname);
       set<string> obtenerVendedores();
        int ingresarProducto(DTProductoSinC dataProducto, string nickVendedor);
       void setContador(int cont);
       int getContador();
       bool esVendedor(string nick, int cod);
       bool existeProducto(int cod);
       ParVendedorProducto mostrarProducto(int prod);
       set<DTProductoCN>  ObtenerListaProductos();
       Producto*  obtenerProducto(DTProductoCN producto);
       set<DTProducto> obtenerListaProdsPendientes(string nick);
       set<CompraProducto*> ObtenerProductos(set <ParCodCant> cc);
       set<DTProducto> productosDelVendedor(string nickname);
       bool estaEnPromoVigente(int cod);
};
#endif
