#ifndef _CONTROLADORUSUARIO_HH_
#define _CONTROLADORUSUARIO_HH_

#include "IUsuarios.hh"
#include "Usuario.hh"
#include "Cliente.hh"
#include <map>
class ControladorUsuarios : public IUsuarios {
private:
    Usuario* UsuarioRecordado;
    
    static ControladorUsuarios* Instancia;

    map<string,Usuario*> ColeccionUsuarios;
    
    DTProductoCN productoAcomentar;

    set<Usuario*> ColeccVendedores;

    int ID;
    
    //SINGLETON
    ControladorUsuarios();
    
public:
    //GETTERS Y SETTERS
    void setUsuarioRecordado(Usuario* aRecordar);
    
    Usuario* getUsuarioRecordado();

    Usuario* getUsuario(string nick);

    void setproductoAcomentar(DTProductoCN producto);

    DTProductoCN getproductoAcomentar();

    void setID(int id);

    int getID();
    
    //SINGLETON
    static ControladorUsuarios* getInstancia();
    
    //INTERFAZ
    string ingresarUsuario(DTUsuario* Usuario);
    
    set<string> obtenerListaClientes();
    
    Usuario* elegirCliente(string nickname);
 
    bool existeUsuario(string nick);

    set<DTVendedor> solicitarSuscribirse (string nickname);
    
    bool seleccionarVendedor(string vendedor);
    
    void confirmarSuscripciones();	
   
    set<string> obtenerVendedores();	
 
    set<string> obtenerListaNicknames();	

    set<DTComentario> obtenerListaComentarios(string usuario);
    
    void eliminarComentario(int comentario);
    
    void eliminarNotificaciones();
        
    set<DTNotificacion> obtenerNotificacionesCliente(string nicnkame);
       
    set<DTVendedor*> vendedoresAsociados(string nick);

    set<string> obtenerUsuarios();

    set<DTProductoCN> obtenerProductos(string usuario);

    void  selecProd(DTProductoCN producto);
    
    void AgregarComentario(string texto);

    set<DTComentario> obtenerListaComentarios();

    void AgregarRespuesta(string texto, int idcomentario);

    set<DTUsuario*> consultarInfoUsuario();
   
    DTExpU* obtenerExpediente(string NUsuario);

    set<string> iniciarExpediente();
        
    ~ControladorUsuarios();
    
    //INTERACCIONES
    void NotificarClientes(string nick,string nombrePromo,set<DTProducto> listaProds);
    
    void confirmarDesuscripciones();
};

#endif
