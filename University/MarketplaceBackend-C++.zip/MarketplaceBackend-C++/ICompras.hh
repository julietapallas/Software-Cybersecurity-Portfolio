#ifndef __ICOMPRAS__
#define __ICOMPRAS__
#include "DT.hh"

class ICompras{
    public:
        virtual set<string> obtenerListaClientes() = 0;
        virtual set<DTProducto> elegirCliente(string nick) = 0;
        virtual bool ingresarProducto(int cod, int cant) = 0;
        virtual ParCompraProductos obtenerDatosCompra() = 0;
        virtual set<DTProducto> obtenerListaProdPendientes(string nick) = 0;
        virtual vector<ParClienteCompra> ObtenerComprasPendientes(int codigo) = 0;
        virtual void CompraProdEnviada(int id) = 0;
        virtual set<string> obtenerVendedores() = 0;
};

#endif