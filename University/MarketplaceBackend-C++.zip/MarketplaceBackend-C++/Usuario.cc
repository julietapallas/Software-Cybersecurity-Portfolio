#include "Usuario.hh"
Usuario :: Usuario(string nick, string cont, DTFecha FN): fechaNacim (FN) {
    nickname = nick;
    contrasenia = cont;
}

Usuario :: ~Usuario(){
}

string Usuario :: getNickname() {
    return nickname;
}

string Usuario :: getContrasenia() {
    return contrasenia;
}

DTFecha Usuario :: getFecha() {
    return fechaNacim;
}

map<string,Usuario*> Usuario :: getSuscriptosOSuscripciones(){
    return SuscriptosOSuscripciones;
}

void Usuario::setSuscriptosOSuscripciones(map<string,Usuario*> sos){
 SuscriptosOSuscripciones=sos;
}

void Usuario::setSOS(string nombre,Usuario* usuario){
     SuscriptosOSuscripciones[nombre] = usuario;
}

void Usuario :: setNickname(string nick) {
    nickname = nick;
}

void Usuario :: setContrasenia(string cont) {
    contrasenia = cont;
}

void Usuario :: setFecha(DTFecha fecha) {
    fechaNacim = fecha;
}

void Usuario::setComentario(Comentario* com){
    ComentariosRealizados.insert(com);
}

void Usuario::eliminarComentario(int comentario){
    set<Comentario*>:: iterator it = ComentariosRealizados.begin();
    while((it != ComentariosRealizados.end())&&!((*it)->getDTComentario().getID() == comentario)){
        ++it;
    }
    if (it != ComentariosRealizados.end()){
    	(*it)->eliminarRespuestas();
    	delete *it;
    	ComentariosRealizados.erase(it);
        Comentario* c = (*it)->getRespondeA();
        if(c != NULL){
            c->eliminarRespuesta(*it);
        }
    }
}

set<DTComentario> Usuario::obtenerComentarios()
{
    set<DTComentario> res;
    for(Comentario* it : ComentariosRealizados){
        res.insert(it->getDTComentario());
    }
    return res;
} 
void Usuario::setComentariosRealizados(set<Comentario*> cr){
    ComentariosRealizados=cr;
}

set<Comentario*> Usuario::getComentariosRealizados(){
    return ComentariosRealizados;
}


bool Usuario::UsuarioAsociado(Usuario* User){
    map<string,Usuario*>:: iterator it = SuscriptosOSuscripciones.begin();
    while(it->second != User && it!= SuscriptosOSuscripciones.end()){
        ++it;
    }

    return it != SuscriptosOSuscripciones.end();

}

void Usuario::setCompra(Compra* CompraRealizada){
    ComprasRealizadas.insert(CompraRealizada);
}

void Usuario::desasociar(Usuario* aDesasociar){
    
    int i = SuscriptosOSuscripciones.erase(aDesasociar->getNickname());
}

void Usuario::eliminarComentario(Comentario* c){
    ComentariosRealizados.erase(c);
}