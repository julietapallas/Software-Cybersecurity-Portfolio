#ifndef __CONTROLADORPROMOCIONES__
#define __CONTROLADORPROMOCIONES__

#include <set>
#include "IPromociones.hh"
#include "Promocion.hh"
class ControladorPromociones: public IPromociones{
    private:
        set<ParCodCant> ListaProds;
        string nickname;
        DTPromocion dataPromo;
        set<Promocion*> ColeccionPromos;
        static ControladorPromociones*  InstControladorPromos;
        ControladorPromociones();
    public:
        void setListaProds(set<ParCodCant> PPC);
        void setNickname(string N);
        void setdataPromo(DTPromocion dtPromo);

        set<ParCodCant> getListaProds();
        string getNickname();
        DTPromocion getdataPromo();

        static ControladorPromociones * getInstancia();
        void ingresarPromo(DTPromocion dataPromo);
        set<string> obtenerVendedores();
        set<DTProductoCN> obtenerProductosVend(string nickname);
        bool selecProd(ParCodCant producto);
        bool altaPromocion();
        set<DTPromocion> IniciarConsulta();
        DTProm DatosPromocion(DTPromocion PromElegida);
        set<DTPromocion> promocionesDelVendedor(string nickname);
        set<Promocion*> getPromociones();
};

#endif
