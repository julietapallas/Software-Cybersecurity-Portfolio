#ifndef __DT__CC__
#define __DT__CC__
#include "DT.hh"

DTFecha::DTFecha(int d,int m,int a){
Dia = d;
Mes = m;
Anio = a;
}

DTFecha::~DTFecha(){

}

int DTFecha:: getDia()const{
    return Dia;
}
int DTFecha:: getMes()const{
    return Mes;
}
int DTFecha:: getAnio()const{
    return Anio;
}

string DTFecha::toString()const{
    return to_string(Dia)+"/"+to_string(Mes)+"/"+to_string(Anio);
}

bool DTFecha::operator==(const DTFecha f)const{
    return Dia==f.getDia() & Mes==f.getMes() & Anio==f.getAnio();
}

bool DTFecha::operator!=(DTFecha f) const {
        return Dia != f.Dia || Mes != f.Mes || Anio != f.Anio;
    }

bool DTFecha::operator<(DTFecha f)const{
    if (Anio != f.getAnio())
            return Anio < f.getAnio();
        if (Mes != f.getMes())
            return Mes < f.getMes();
        return Dia < f.getDia();
}

bool DTFecha::operator<=(DTFecha f){
    if (Anio != f.getAnio())
            return Anio <= f.getAnio();
        if (Mes != f.getMes())
            return Mes <= f.getMes();
        return Dia <= f.getDia();
}

string toStringDTCategoria(DTCategoria cat) {
    switch (cat) {
        case DTCategoria::Electrodomestico:
            return "Electrodomestico";
		case DTCategoria::Ropa:
            return "Ropa";
        default:
            return "Otro";
    }
}


DTUsuario::DTUsuario(string n, string c, DTFecha f):FechaNac(f){
    Nickname = n;
    Contrasenia = c;
}

DTUsuario::~DTUsuario(){

}



string DTUsuario:: getNickname()const{
    return Nickname;
}

string DTUsuario:: getContrasenia()const{
    return Contrasenia;
}

DTFecha DTUsuario:: getFechaNac()const{
    return FechaNac;
}



DTDireccion::DTDireccion(string c, int n){
    Calle = c;
    NumPuerta = n;
}

DTDireccion::~DTDireccion(){

}

string DTDireccion:: getCalle(){
    return Calle;
}

int DTDireccion:: getNumPuerta(){
    return NumPuerta;
}



DTProducto::DTProducto(string n, string d, string c, float p, int s, DTCategoria cat){
    Nombre = n;
    Descripcion = d;
    Codigo = c;
    Precio = p;
    Stock = s;
    Categoria = cat;
}

DTProducto::~DTProducto(){

}

string DTProducto::getNombre()const{
    return Nombre;
}

string DTProducto::getDescripcion()const{
    return Descripcion;
}

string DTProducto::getCodigo()const{
    return Codigo;
}

float DTProducto::getPrecio()const{
    return Precio;
}

int DTProducto::getStock()const{
    return Stock;
}

DTCategoria DTProducto::getCategoria()const{
    return Categoria;
}

bool DTProducto::operator<(const DTProducto &other) const{
    return stoi(Codigo) < stoi(other.getCodigo());
}

string DTProducto:: toString()const{
    string ret = "Nombre: " + getNombre() + "\n" + "Descripcion: " + getDescripcion() + "\n" + "Código: " + getCodigo() + "\n" + "Precio: " + to_string(getPrecio()) + "\n" + "Stock: " + to_string(getStock()) + "\n" + "Categoria: " + toStringDTCategoria(getCategoria()); 
    return ret;
}
DTProductoCN::DTProductoCN(string n, string c){
    Nombre = n;
    Codigo = c;
}

DTProductoCN::~DTProductoCN(){}

string DTProductoCN::getNombre()const{
    return Nombre;
}

string DTProductoCN::getCodigo()const {
    return Codigo;
}

bool DTProductoCN::operator<(const DTProductoCN Pcn) const {
    return stoi(Codigo) < stoi(Pcn.getCodigo());
}

string DTProductoCN::toString()const {
    string ret = "Nombre: " + getNombre() + "\n";
    ret = ret + "Código: " + getCodigo()+ "\n";
    return ret;
}


DTProductoInfo::DTProductoInfo(float p, int s, string d, DTCategoria c){
    Precio = p;
    Stock = s;
    Descripcion = d;
    Categoria = c;
}

DTProductoInfo::~DTProductoInfo(){}

string DTProductoInfo::getDescripcion(){
    return Descripcion;
}

float DTProductoInfo::getPrecio(){
    return Precio;
}

int DTProductoInfo::getStock(){
    return Stock;
}

DTCategoria DTProductoInfo::getCategoria(){
    return Categoria;
}


string DTProductoInfo::toString(){
    string ret = "Precio: " + to_string(getPrecio()) + "\n";
    ret = ret + "Stock: " + to_string(getStock()) + "\n";
    ret = ret + "Descripción: " + getDescripcion() + "\n";
    ret = ret + "Categoría: " + toStringDTCategoria(getCategoria()) + "\n";
    return ret;
}

DTProductoSinC::DTProductoSinC(string nombre, string desc, float precio, int stock, DTCategoria cat ){
Nombre=nombre;
Descripcion=desc;
Precio=precio;
Stock=stock;
Categoria=cat;
}
DTProductoSinC::~DTProductoSinC(){}

string DTProductoSinC::getNombre(){
    return Nombre;
}

string DTProductoSinC::getDescripcion(){
    return Descripcion;
}


float DTProductoSinC::getPrecio(){
    return Precio;
}

int DTProductoSinC::getStock(){
    return Stock;
}

DTCategoria DTProductoSinC::getCategoria(){
    return Categoria;
}


ParVendedorProducto::ParVendedorProducto(string nv, DTProductoInfo p):Producto(p){
    NickVendedor = nv;
    Producto = p;
}

ParVendedorProducto::~ParVendedorProducto(){}

string ParVendedorProducto::getNickVendedor(){
    return NickVendedor;
}

DTProductoInfo ParVendedorProducto::getProducto(){
    return Producto;
}



DTNotificacion::DTNotificacion(string nv, string np, set<DTProducto> p){
    NicknameVendedor = nv;
    NombrePromocion = np;
    Productos = p;
}

DTNotificacion::~DTNotificacion(){

}

string DTNotificacion:: getNicknameVendedor()const{
    return NicknameVendedor;
}

string DTNotificacion:: getNombrePromocion()const{
    return NombrePromocion;
}

set<DTProducto> DTNotificacion:: getProductos()const{
    return Productos;
}

bool DTNotificacion:: operator<(const DTNotificacion& other) const {
        return NicknameVendedor < other.NicknameVendedor ; 
    }

DTCliente::DTCliente(string nombre, string contrasenia, DTFecha fechanac, DTDireccion d, string c, set<DTNotificacion> n):DTUsuario(nombre,contrasenia,fechanac), Direccion(d){
    Ciudad = c;
    Notificaciones= n;
}

DTCliente::~DTCliente(){

}

DTDireccion DTCliente:: getDireccion()const{
    return Direccion;
}

string DTCliente:: getCiudad()const{
    return Ciudad;
}

set<DTNotificacion> DTCliente:: getNotificaciones()const{
    return Notificaciones;
}

string DTCliente::toString()const{
    string ret = "Nickname cliente: " + getNickname() + "\n";
    ret = ret + "Fecha de nacimiento: " + getFechaNac().toString() + "\n";
    ret = ret + "Dirección: Calle: " + getDireccion().getCalle() + " Número de Puerta: " +to_string(getDireccion().getNumPuerta()) + "\n";
    ret = ret + "Ciudad: " + getCiudad() + "\n";
    return ret;

}

DTVendedor::DTVendedor(string nombre, string contrasenia, DTFecha fechanac, string cRUT) :DTUsuario(nombre,contrasenia,fechanac){
    CodigoRUT = cRUT; 
}

DTVendedor::~DTVendedor(){

}

string DTVendedor:: getCodigoRUT()const{
    return CodigoRUT;
}

bool DTVendedor::operator<(const DTVendedor& otro) const {
    return getCodigoRUT() < otro.getCodigoRUT();
}


string DTVendedor::toString()const{
    string ret = "Nickname vendedor: " + getNickname() + "\n";
    ret = ret +"Fecha de nacimiento: " + getFechaNac().toString()+ "\n";
    ret = ret + "Código RUT: " + getCodigoRUT()+ "\n";
    return ret;
}

DTPromocion::DTPromocion():FechaVenc(0,0,0){}


DTPromocion::DTPromocion(string N, string Descrip, float Descu, DTFecha FV):FechaVenc(FV){
Nombre = N;
Descripcion = Descrip;
Descuento = Descu;
}

DTPromocion::~DTPromocion(){
}

string DTPromocion::getNombre()const{
	return Nombre;
}

string DTPromocion::getDescripcion()const{
	return Descripcion;
}

float DTPromocion::getDescuento()const{
	return Descuento;
}

DTFecha DTPromocion::getFechaVenc()const{
	return FechaVenc;
}

bool DTPromocion::operator<(DTPromocion p) const {
    if (Nombre != p.Nombre) {
        return Nombre < p.Nombre;
    } else if (FechaVenc != p.FechaVenc) {
        return FechaVenc < p.FechaVenc;
    } else {
        return Descuento < p.Descuento;
    }
}

bool DTPromocion::operator==(DTPromocion p) const {
    return Nombre == p.getNombre() & Descripcion == p.getDescripcion() & Descuento == p.getDescuento() & FechaVenc == p.getFechaVenc();
}

string DTPromocion::toString()const{
    string ret = "Nombre: " + getNombre() + "\n";
    ret = ret + "Descripción: " + getDescripcion() + "\n";
    ret = ret + "Descuento: " + to_string(getDescuento()) + "\n";
    ret = ret + "Fecha de vencimiento: " + getFechaVenc().toString()+ "\n";
    return ret;
}

DTComentario::DTComentario(string T, DTFecha F,int id):Fecha(F){
Texto = T;
ID=id;
}

DTComentario::~DTComentario(){
}

string DTComentario:: getTexto()const{
	return Texto;
}

DTFecha DTComentario:: getFecha()const{
	return Fecha;
}
int DTComentario:: getID()const{
    return ID;
}


bool DTComentario::operator<(const DTComentario& com)const{
    return getID() < com.getID();
}


bool DTComentario::operator==(const DTComentario &com) const{
    return (getTexto() == com.getTexto()) && (getFecha().toString() == com.getFecha().toString());
}

string DTComentario::toString()const{
    string ret = "Identificador: " + to_string(getID()) + "\n";
    ret = ret + "Texto: " + getTexto() + "\n";
    ret = ret + "Fecha: " + getFecha().toString() + "\n";
    return ret;
}

DTCompra::DTCompra(float P, DTFecha F):Fecha(F){
Precio = P;
}

DTCompra::~DTCompra(){
}

float DTCompra::getPrecio()const{
	return Precio;
}

DTFecha DTCompra::getFecha()const{
	return Fecha;
}

string DTCompra :: toString()const{
    string ret =  "Fecha: " + getFecha().toString() + "\n";
    ret = ret + "Monto: " + to_string(getPrecio()) + "\n";
    return ret;
}


ParCompraProductos:: ParCompraProductos(DTCompra C, set<DTProducto> Ps):Compra(C){
Productos = Ps;
}

ParCompraProductos::~ParCompraProductos(){
}

DTCompra ParCompraProductos::getCompra()const{
	return Compra;
}

 set<DTProducto> ParCompraProductos::getProductos()const{
	return Productos;
}

bool ParCompraProductos::operator<(const ParCompraProductos p)const{
    DTFecha f = Compra.getFecha();
    DTCompra cp = p.getCompra();
    DTFecha fp = cp.getFecha();
    return f < fp;
}


ParCodCant:: ParCodCant(int Cod, int Cant){
    Codigo = Cod;
    Cantidad = Cant;
}

ParCodCant:: ~ParCodCant(){

}

int ParCodCant:: getCodigo()const{
    return Codigo;
}

int ParCodCant:: getCantidad()const{
    return Cantidad;
}


bool ParCodCant ::operator<(const ParCodCant& parPC) const {
    return Codigo < parPC.Codigo;
}


DTExpC::DTExpC(DTCliente cliente,set<ParCompraProductos> compras):Cliente(cliente){
    Compras = compras;
}

DTCliente DTExpC::getCliente(){
    return Cliente;
}

set<ParCompraProductos> DTExpC::getCompras()const{
    return Compras;
}

DTExpC::~DTExpC(){}

string DTExpC::toString()const{
    string ret = "";
    set<ParCompraProductos>::iterator it;
    ret = ret + Cliente.toString();
    for(it = Compras.begin(); it!=Compras.end();++it){
        ret = ret + "\nDatos Compra:\n\n" + (*it).getCompra().toString();
        ret = ret + "\nProductos:\n\n";
        set<DTProducto> prods = (*it).getProductos();
        set<DTProducto>::iterator i;
        for(i = prods.begin(); i!= prods.end(); ++i){
           ret = ret + (*i).toString() + "\n";
        }
    }
    return ret;
}

DTExpV::DTExpV(DTVendedor vendedor,set<DTProducto> productos,set<DTPromocion> promociones):Vendedor(vendedor){
    Productos = productos;
    Promociones = promociones;
}
	
DTExpV::~DTExpV(){};
        
DTVendedor DTExpV::getVendedor(){
    return Vendedor;
}
	
set<DTProducto> DTExpV::getProductos()const{
    return Productos;
}
	
set<DTPromocion> DTExpV::getPromociones()const{
    return Promociones;
}

string DTExpV::toString()const{
    string ret = Vendedor.toString();
    ret = ret + "Productos que tiene a la venta:\n\n";
    set<DTProducto>::iterator i;
    for(i = Productos.begin(); i!= Productos.end(); ++i){
            ret = ret + (*i).toString() + "\n\n";
    }
    ret = ret + "\nPromociones vigentes:" +"\n\n";
    set<DTPromocion>::iterator it;
        for(it = Promociones.begin(); it!= Promociones.end(); ++it){
            ret = ret + (*it).toString() + "\n";
        }
    return ret;

}

FechaAct::FechaAct(){}

FechaAct* FechaAct::Instancia = nullptr;

FechaAct* FechaAct::getInstancia(){
    if (Instancia == nullptr){
        Instancia = new FechaAct();
    }
    return Instancia;
}

int FechaAct::getDia(){
    return dia;
}

int FechaAct::getMes(){
    return mes;
}

int FechaAct::getAnio(){
    return anio;
}

void FechaAct::setDia(int d){
    dia = d;
}

void FechaAct::setMes(int m){
    mes = m;
}

void FechaAct::setAnio(int a){
    anio = a;
}

DTFecha FechaAct::getDTFecha(){
    DTFecha Actual(dia,mes,anio);
    return Actual;
}

ParClienteCompra::ParClienteCompra(string nickCliente,int idComp, DTFecha fechaCom):fechaCompra(fechaCom){
    nicknameCliente = nickCliente;
    idCompra = idComp;
}

string ParClienteCompra::getNickname(){
    return nicknameCliente;
}

int ParClienteCompra::getId(){
    return idCompra;
}

DTFecha ParClienteCompra::getFechaC(){
    return fechaCompra;
}

DTProd::DTProd(DTProducto P,int CantMin):Producto(P.getNombre(),P.getDescripcion(),P.getCodigo(),P.getPrecio(),P.getStock(),P.getCategoria()){
    this->CantMin = CantMin;
}

DTProd::~DTProd(){};
    
DTProducto DTProd::getDTProducto()const{
    return Producto;
}

int DTProd::getCantMin()const{
    return CantMin;
}
    
void DTProd::setDTProducto(DTProducto Producto){
    this->Producto = Producto;
}
    
void DTProd::setCantMin(int CantMIn){
    this->CantMin = CantMin;
}

bool DTProd::operator<(DTProd p)const{
    return CantMin < p.getCantMin();
}

string DTProd::toString()const{
    string ret = "Código: " + getDTProducto().getCodigo() + "\n";
    ret = ret + "Nombre: " + getDTProducto().getNombre() + "\n";
    ret = ret + "Precio: " + to_string(getDTProducto().getPrecio()) + "\n";
    ret = ret + "Stock: " + to_string(getDTProducto().getStock()) + "\n";
    ret = ret + "Descripción: " + getDTProducto().getDescripcion() + "\n";
    ret = ret + "Categoría: " + toStringDTCategoria(getDTProducto().getCategoria()) + "\n";
    ret = ret + "Cantidad mínima: " + to_string(getCantMin()) + "\n";
    return ret;
}

DTProm::DTProm(DTVendedor Vend,set<DTProd> productos):Vendedor(Vend.getNickname(),Vend.getContrasenia(),Vend.getFechaNac(),Vend.getCodigoRUT()){
    ProdDeProm = productos;
}

DTProm::~DTProm(){};
	
DTVendedor DTProm::getVendedor(){
    return Vendedor;
}
        
set<DTProd> DTProm::getProdDeProm(){
    return ProdDeProm;
}
        
void DTProm::setVendedor(DTVendedor Vendedor){
    this->Vendedor = Vendedor;
}

void DTProm::setProd(DTProd Prod){
    ProdDeProm.insert(Prod);
}

#endif
