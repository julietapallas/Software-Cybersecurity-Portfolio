#include"Cliente.hh"
#include"Vendedor.hh"
#include "ControladorCompras.hh"
Cliente :: Cliente(string nick, string cont, string ciud, DTFecha FN, DTDireccion dir, set<DTNotificacion> notif): Usuario (nick, cont, FN),direccion(dir) {
    notificaciones = notif;
    ciudad = ciud;
}

Cliente :: ~Cliente(){
}

DTDireccion Cliente :: getDireccion () {
    return direccion;
}

string Cliente :: getCiudad () {
    return ciudad;
}

set<DTNotificacion> Cliente :: getNotificaciones () {
    return notificaciones;
}

void Cliente :: setDireccion (DTDireccion dir) {
    direccion = dir;
}

void Cliente :: setCiudad(string ciud) {
    ciudad = ciud;
}

void Cliente :: setNotificaciones (set<DTNotificacion> notif) {
    notificaciones = notif;
}

void Cliente :: obtenerNotificaciones() {

}

void Cliente :: notificar(string nick, string nombrePromo, set<DTProducto> ListaProds) {
    DTNotificacion Notificacion(nick,nombrePromo,ListaProds);
    notificaciones.insert(Notificacion);
}
set<DTVendedor*> Cliente :: vendedoresAsociados() {
    set<DTVendedor*> asociados = {};
    map<string,Usuario*> vendedores = getSuscriptosOSuscripciones();
    map<string,Usuario*>::iterator it = vendedores.begin();
    for(it;it != vendedores.end();it++){
        Vendedor* v = dynamic_cast<Vendedor*>(it->second);
        DTVendedor dtv = v->getDTVendedor();
        DTVendedor* pv = new DTVendedor(dtv.getNickname(),dtv.getContrasenia(),dtv.getFechaNac(),dtv.getCodigoRUT());
        asociados.insert(pv);
    }
    return asociados;

}

void Cliente:: eliminarNotificaciones(){
    notificaciones.clear();
}

DTExpU* Cliente::obtenerExpediente(){
    DTCliente cliente(getNickname(),getContrasenia(),getFecha(),direccion,ciudad,notificaciones);
    
    ControladorCompras* CC = ControladorCompras::getInstancia();
    set<ParCompraProductos> compras = CC->ComprasDeVend(getNickname());
    
    DTExpC *expediente = new DTExpC(cliente,compras);
    return expediente;
}

