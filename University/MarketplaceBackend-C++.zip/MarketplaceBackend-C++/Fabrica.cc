#include "Fabrica.hh"
#include "ControladorPromociones.hh"
#include "ControladorCompras.hh"
#include "ControladorUsuarios.hh"
#include "ControladorProductos.hh"


IPromociones* Fabrica::getContPromocion(){
    return ControladorPromociones :: getInstancia();
}

ICompras* Fabrica::getContCompras(){
    return ControladorCompras :: getInstancia();
}

IUsuarios* Fabrica::getContUsuarios(){
    return ControladorUsuarios::getInstancia();
}

IProductos* Fabrica::getContProductos(){
    return ControladorProductos:: getInstancia();
}
