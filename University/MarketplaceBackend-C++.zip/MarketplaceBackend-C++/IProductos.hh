#ifndef __IPRODUCTOS__HH
#define __IPRODUCTOS__HH
#include "DT.hh"

class Producto;
class Promocion;
 
class IProductos{ 
    public:
       virtual set<DTProducto> elegirCliente(string nick)=0;
       virtual set<DTProductoCN>  ObtenerListaProductos()=0;
       virtual set<DTProducto> AsociarProductos(set <ParCodCant> ListaProds,Promocion* p) = 0; 
       virtual int ingresarProducto(int cod, int cant)=0;
       virtual float ObtenerPrecio(set <ParCodCant> cc)=0; 
       virtual set<DTProductoCN> ObtenerProductosVend(string nickname)=0;
       virtual int ingresarProducto(DTProductoSinC dataProducto, string nickVendedor)=0;
       virtual bool esVendedor(string nick, int cod)=0;
       virtual Producto*  obtenerProducto(DTProductoCN producto)=0;
       virtual set<string> obtenerVendedores()=0;
       virtual bool existeProducto(int cod)=0;
       virtual ParVendedorProducto mostrarProducto(int prod) = 0;
       virtual ~IProductos(){};
};  
#endif 