#ifndef __DT__HH__
#define __DT__HH__
#include <string>
#include <set>
using namespace std;


class DTNotificacion;


class DTFecha {
private:
	int Dia,Mes,Anio;
public:
	DTFecha(int d,int m,int a);
	~DTFecha();
	virtual string toString()const;
	int getDia()const;
	int getMes()const;
	int getAnio()const;
	bool operator<(DTFecha f)const;
	bool operator==(const DTFecha f)const;
	bool operator<=(DTFecha f);
	bool operator!=(DTFecha f) const;
};


enum class DTCategoria {
    Ropa,
    Electrodomestico,
    Otro
};	

string toStringDTCategoria(DTCategoria cat);

class DTDireccion {
private:
	string Calle;
	int NumPuerta;
public:
	DTDireccion(string Calle, int NumPuerta);
	~DTDireccion();
	string getCalle();
	int getNumPuerta();
};


class DTUsuario{
private: 
	string Nickname, Contrasenia;
	DTFecha FechaNac;
public:
	DTUsuario(string Nickname, string Contrasenia, DTFecha FechaNac);
	virtual ~DTUsuario()=0;
	string getNickname()const;
	string getContrasenia()const;
	DTFecha getFechaNac()const;
	virtual string toString()const = 0;
};



class DTCliente: public DTUsuario {
private:
	DTDireccion Direccion;
	string Ciudad;
	set<DTNotificacion> Notificaciones;
public:
	DTCliente(string Nombre, string Contrasenia, DTFecha FechaNac, DTDireccion Direccion, string Ciudad, set<DTNotificacion> Notificaciones);
	~DTCliente();
	DTDireccion getDireccion()const;
	string getCiudad()const;
	set<DTNotificacion> getNotificaciones()const;
	string toString()const;
};


class DTVendedor: public DTUsuario{
private:
	string CodigoRUT;
public:
	DTVendedor(string Nombre, string Contrasenia, DTFecha FechaNac, string CodigoRUT);
	~DTVendedor();
	string getCodigoRUT()const;
	bool operator<(const DTVendedor&  otro) const;
	string toString()const;
};


class DTProducto{
private:
	string Nombre, Descripcion, Codigo;
	float Precio;
	int Stock;
	DTCategoria Categoria;
public:
	DTProducto(string Nombre, string Descripcion, string Codigo, float Precio, int Stock, DTCategoria Categoria);
	~DTProducto();
	string getNombre()const;
	string getDescripcion()const;
	string getCodigo()const;
	float getPrecio()const;
	int getStock()const;
	DTCategoria getCategoria()const;
	bool operator<(const DTProducto& prod) const; 
	string toString()const;
	
};


class DTProductoCN{
private:
	string Nombre, Codigo;
public:
	DTProductoCN(string Nombre, string Codigo);
	DTProductoCN();
	~DTProductoCN();
	string getNombre() const ;
	string getCodigo() const;
	bool operator<(const DTProductoCN Pcn) const;
	string toString()const;
};


class DTProductoInfo{
private:
	float Precio;
	int Stock;
	string Descripcion;
	DTCategoria Categoria;
public:
	DTProductoInfo(float Precio, int Stock, string Descripcion, DTCategoria Categoria);
	~DTProductoInfo();
	string getDescripcion();
	float getPrecio();
	int getStock();
	DTCategoria getCategoria();
	string toString();
};
class DTProductoSinC{
private:
	string Nombre,Descripcion;
	float Precio;
	int Stock;
	DTCategoria Categoria;
public:
	DTProductoSinC(string Nombre, string Descripcion, float Precio, int Stock, DTCategoria Categoria);
	~DTProductoSinC();
	string getNombre();
	string getDescripcion();
	float getPrecio();
	int getStock();
	DTCategoria getCategoria();

};


class ParVendedorProducto{
private:
	string NickVendedor;
	DTProductoInfo Producto;
public:
	ParVendedorProducto(string NickVendedor, DTProductoInfo Producto);
	~ParVendedorProducto();
	string getNickVendedor();
	DTProductoInfo getProducto();
};


class DTNotificacion{
private:
	string NicknameVendedor, NombrePromocion;
	set<DTProducto> Productos;
public:
	DTNotificacion(string NicknameVendedor, string NombrePromocion, set<DTProducto> Productos);
	~DTNotificacion();
	string getNicknameVendedor()const;
	string getNombrePromocion()const;
	set<DTProducto> getProductos()const;
	bool operator<(const DTNotificacion& notif) const;
};


class DTPromocion{
private:
	string Nombre, Descripcion;
	float Descuento;
	DTFecha FechaVenc;
public: 
	DTPromocion();
	DTPromocion(string Nombre, string Descripcion, float Descuento, DTFecha FechaVenc);
	~DTPromocion();
	string getNombre()const;
	string getDescripcion()const;
	float getDescuento()const;
	DTFecha getFechaVenc()const;
	bool operator<(DTPromocion p)const;
    bool operator==(DTPromocion p)const;
	string toString()const;	
};


class DTComentario{
private:
	string Texto;
	DTFecha Fecha;
	int ID;
public: 
	DTComentario(string Texto, DTFecha Fecha,int ID);
	~DTComentario();
	string getTexto()const;
	DTFecha getFecha()const;
	int getID()const;
	bool operator<(const DTComentario& com)const;
	bool operator==(const DTComentario& com)const;
	string toString()const;
};


class DTCompra{
private:
	float Precio;
	DTFecha Fecha;
public:
	DTCompra(float Precio, DTFecha Fecha);
	~DTCompra();
	float getPrecio()const;
	DTFecha getFecha()const;
	string toString()const;
};


class ParCompraProductos {
private:
	DTCompra Compra;
	set<DTProducto> Productos;
public:
	ParCompraProductos(DTCompra Compra, set<DTProducto> Productos);
	~ParCompraProductos();
	DTCompra getCompra()const;
	set<DTProducto> getProductos()const;
	bool operator<(const ParCompraProductos p)const;
};


class ParCodCant{
private:
	int Codigo;
	int Cantidad;
public:
	ParCodCant(int Cod, int Cant);
	~ParCodCant();
	int getCodigo()const;
	int getCantidad()const;
	bool operator<(const ParCodCant& otro) const;
};


class DTExpU {
public:
	virtual ~DTExpU(){};
	virtual string toString()const = 0;
};


class DTExpC : public DTExpU{
private:
        DTCliente Cliente;
	set<ParCompraProductos> Compras;
public:
	DTExpC(DTCliente cliente,set<ParCompraProductos> compras);
        DTCliente getCliente();
        set<ParCompraProductos> getCompras()const;
	~DTExpC();
	string toString()const;
};

class DTExpV : public DTExpU{
private:
        DTVendedor Vendedor;
	set<DTProducto> Productos;
	set<DTPromocion> Promociones;
public:
	DTExpV(DTVendedor vendedor,set<DTProducto> productos,set<DTPromocion> promociones);
	~DTExpV();
        DTVendedor getVendedor();
	set<DTProducto> getProductos()const;
	set<DTPromocion> getPromociones()const;
	string toString()const;
};



class FechaAct{
private:
	int dia;
	int mes;
	int anio;
	static FechaAct * Instancia;
	FechaAct();
public:
	static FechaAct* getInstancia();
	int getDia();
	int getMes();
	int getAnio();
	void setDia(int dia);
	void setMes(int mes);
	void setAnio(int anio);
	DTFecha getDTFecha();
};



class ParClienteCompra{
	private:
		DTFecha fechaCompra;
		string nicknameCliente;
		int idCompra;
	public:
		ParClienteCompra(string nickCliente,int idC,DTFecha fechaC);
		string getNickname();
		int getId();
		DTFecha getFechaC();
};

class DTProd{
private:
	DTProducto Producto;
	int CantMin;
public:
    DTProd(DTProducto Producto,int CantMin);
    ~DTProd();
    DTProducto getDTProducto()const;
    int getCantMin()const;
    void setDTProducto(DTProducto Producto);
    void setCantMin(int CantMIn);
    bool operator<(DTProd p)const;
	string toString()const;
};

class DTProm{
private:
	DTVendedor Vendedor;
	set<DTProd> ProdDeProm;
public:
	DTProm(DTVendedor Vendedor,set<DTProd> productos);
    ~DTProm();
	DTVendedor getVendedor();
    set<DTProd> getProdDeProm();
    void setVendedor(DTVendedor Vendedor);
    void setProd(DTProd Prod);
};



#endif