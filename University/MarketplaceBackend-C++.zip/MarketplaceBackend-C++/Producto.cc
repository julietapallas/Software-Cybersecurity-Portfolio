#include "Producto.hh"
#include "Promocion.hh"
#include"PromocionProducto.hh"
#include"CompraProducto.hh"

Producto::Producto(string N,float P, int S, string Desc, DTCategoria Cat, int Cod, Usuario* vend, PromocionProducto* promoprod, vector<CompraProducto*> compras){
    Nombre = N;
    Precio = P;
    Stock = S;
    Descripcion = Desc;
    Categoria = Cat;
    Codigo = Cod;
    Vendedor = vend;
    PP = promoprod;
    CP = compras;
}
DTProductoCN::DTProductoCN(){

}
Producto::~Producto(){

}

void Producto::setNombre(string N){
    Nombre = N;
}

void Producto::setDescripcion(string Desc){
    Descripcion = Desc;
}

void Producto::setCodigo(int Cod){
    Codigo = Cod;
}

void Producto::setPrecio(float P){
    Precio = P;
}

void Producto::setStock(int S){
    Stock = S;
}

void Producto::setCategoria(DTCategoria Cat){
    Categoria = Cat;
}

void Producto::setPromProd(PromocionProducto* pp) {
    PP=pp;
    
}
 void Producto:: setCompraProd(CompraProducto *cp){
    CP.push_back(cp);
 }

void Producto:: setVendedor(Usuario* vend){
    Vendedor = vend;
}

DTProducto Producto::getDTProducto(){
    return DTProducto(Nombre,Descripcion,to_string(Codigo),Precio,Stock,Categoria);
}

int Producto::getStock(){
    return Stock;
}

float Producto::getPrecio(){
    return Precio;
}

string Producto::getNombre(){
    return Nombre;
}

int Producto::getCodigo(){
    return Codigo;
}

string Producto::getDescripcion(){
    return Descripcion;
}

DTCategoria Producto::getCategoria(){
    return Categoria;
}

PromocionProducto* Producto::getPromProd(){
    return PP;
}

Usuario* Producto :: getVendedor(){
    return Vendedor;
}

void Producto::Asociar(CompraProducto * cp){
  CP.push_back(cp);
}

void Producto::Asociar(PromocionProducto *pp){
    PP=pp;

}

bool Producto::prodValido(string nick ) { 
    bool NomVend = (nick == Vendedor->getNickname());
    bool vencida = false;
    if (PP != nullptr){
        DTFecha f = PP->getFecha();
        FechaAct* InstFActual = FechaAct::getInstancia();
        DTFecha factual(InstFActual->getDia(),InstFActual->getMes(), InstFActual->getAnio());
        vencida = (factual < f);
    }
    bool valido = (NomVend && !vencida);
return valido;
}


bool Producto::ProductoPendiente(string nick){
    bool ret = false;
    if (nick == getVendedor()->getNickname()){
        for (int i = 0; i< CP.size() && !ret ; i++){
            if (!CP[i]->getEnviado()){
                ret = true;
            }
        }
    }

    return ret;
}

void Producto::setComentario(Comentario * nuevocoment){
    ComentariosRealizados.insert(nuevocoment);
}
void Producto::eliminarComentario(DTComentario comentario){
    set<Comentario*>:: iterator it = ComentariosRealizados.begin();
    while(!((*it)->getDTComentario() == comentario)){
        ++it;
    }
    (*it)->eliminarRespuestas();
    delete *it;
    ComentariosRealizados.erase(it);
}

void Producto::setComentariosRealizados(set<Comentario*> cr){
    ComentariosRealizados=cr;
}

set<Comentario*> Producto::getComentariosRealizados(){
    return ComentariosRealizados;
}

set<DTComentario> Producto::obtenerComentarios()
{
    set<DTComentario> res;
    for(Comentario* it : ComentariosRealizados){
        res.insert(it->getDTComentario());
    }
    return res;
} 


